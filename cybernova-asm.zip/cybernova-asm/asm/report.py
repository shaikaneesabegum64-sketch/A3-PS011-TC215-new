"""Alert and change reports (Markdown, HTML and JSON)."""
import html
import json
from typing import Dict, List, Optional

from .rules import SEVERITY_ORDER
from .util import iso, utcnow


def _short(v, n=90):
    s = v if isinstance(v, str) else json.dumps(v, sort_keys=True)
    return s if len(s) <= n else s[: n - 1] + "..."


def _change_rows(changes: List[Dict]):
    return [[c["change"], c["asset_type"], c["key"], _short(c["before"] or "-"), _short(c["after"] or "-")]
            for c in changes] or [["-", "-", "no changes", "-", "-"]]


def build_sections(scope, snapshot: Dict, alerts: List[Dict], assets: Dict,
                   chg_base: List[Dict], chg_prev: List[Dict], evaluation: Optional[Dict]):
    active = sorted([a for a in alerts if a["status"] != "false_positive"],
                    key=lambda a: (SEVERITY_ORDER[a["severity"]], a["rule"], a["asset_key"]))
    suppressed = [a for a in alerts if a["status"] == "false_positive"]
    sev_count = {s: sum(1 for a in active if a["severity"] == s) for s in SEVERITY_ORDER}
    by_type = {}
    for (t, _), _d in assets.items():
        by_type[t] = by_type.get(t, 0) + 1

    secs = []
    secs.append(("Summary", ["Item", "Value"], [
        ["Organisation", scope.organisation],
        ["Scope approval", f"{scope.reference} (approved by {scope.approved_by}, valid {scope.valid_from:%Y-%m-%d} to {scope.valid_until:%Y-%m-%d})"],
        ["Snapshot", f"#{snapshot['id']} ({snapshot['kind']}) started {snapshot['started_at']}"],
        ["Assets tracked", ", ".join(f"{k}: {v}" for k, v in sorted(by_type.items()))],
        ["Active alerts", ", ".join(f"{k}: {v}" for k, v in sev_count.items() if v) or "none"],
        ["Dismissed false positives", str(len(suppressed))],
        ["Report generated", iso(utcnow())],
    ]))
    secs.append(("Active alerts", ["Severity", "Rule", "Asset", "Finding", "New"],
                 [[a["severity"].upper(), a["rule"], a["asset_key"], a["title"], "yes" if a["is_new"] else "no"] for a in active]
                 or [["-", "-", "-", "no active alerts", "-"]]))
    secs.append(("Dismissed as false positives", ["Rule", "Asset", "Reason"],
                 [[a["rule"], a["asset_key"], a["fp_reason"] or ""] for a in suppressed] or [["-", "-", "none"]]))
    secs.append(("Changes since baseline", ["Change", "Type", "Asset", "Before", "After"], _change_rows(chg_base)))
    secs.append(("Changes since previous scan", ["Change", "Type", "Asset", "Before", "After"], _change_rows(chg_prev)))

    svc = [[k[1], d.get("state"), d.get("service"), _short(d.get("banner", ""), 40), "yes" if d.get("tls") else "no"]
           for k, d in sorted(assets.items()) if k[0] == "service" and d.get("state") == "open"]
    secs.append(("Exposed services (open)", ["Endpoint", "State", "Service", "Banner", "TLS"], svc or [["-", "-", "-", "-", "-"]]))
    certs = [[k[1], d.get("subject_cn", ""), d.get("not_after", d.get("error", "")),
              str(d.get("days_remaining", "")), "EXPIRED" if d.get("expired") else "ok"]
             for k, d in sorted(assets.items()) if k[0] == "tls_cert"]
    secs.append(("TLS certificates", ["Endpoint#SNI", "Subject CN", "Not after", "Days left", "Status"], certs or [["-"] * 5]))
    dns = [[k[1], ", ".join(d["values"])] for k, d in sorted(assets.items()) if k[0] == "dns_record"]
    secs.append(("DNS records", ["Record", "Values"], dns or [["-", "-"]]))

    if evaluation:
        secs.append(("Seeded-issue detection results", ["ID", "Type", "Asset", "Detected", "Severity"],
                     [[r["id"], r["type"], r["asset_key"], "YES" if r["detected"] else "MISSED", r["severity"]]
                      for r in evaluation["seeded_results"]]))
        secs.append(("Detection metrics", ["Metric", "Value"], [
            ["Seeded issues", evaluation["seeded_total"]], ["True positives", evaluation["true_positives"]],
            ["False negatives", evaluation["false_negatives"]],
            ["False positives (raw)", evaluation["false_positives_raw"]],
            ["False positives (after analyst review)", evaluation["false_positives_after_review"]],
            ["Recall", evaluation["recall"]], ["Precision (raw)", evaluation["precision_raw"]],
            ["Precision (after review)", evaluation["precision_after_review"]]]))
        secs.append(("False-positive analysis", ["Asset", "Rule", "Outcome", "Reason"],
                     [[f["asset_key"], f["rule"], f["outcome"], f["reason"]] for f in evaluation["false_positive_analysis"]]
                     or [["-", "-", "no false positives", "-"]]))
    return secs


def render_markdown(title: str, secs) -> str:
    out = [f"# {title}", ""]
    for name, head, rows in secs:
        out += [f"## {name}", "", "| " + " | ".join(head) + " |", "|" + "---|" * len(head)]
        out += ["| " + " | ".join(str(c).replace("|", "/") for c in r) + " |" for r in rows]
        out.append("")
    return "\n".join(out)


def render_html(title: str, secs) -> str:
    css = ("body{font-family:system-ui,sans-serif;margin:2rem auto;max-width:1100px;color:#1f2a44}"
           "h1{border-bottom:3px solid #0e9aa7}h2{color:#0e9aa7}table{border-collapse:collapse;width:100%;margin-bottom:1.5rem}"
           "th{background:#1f2a44;color:#fff;text-align:left}td,th{border:1px solid #cbd5e1;padding:6px 8px;font-size:13px}"
           "tr:nth-child(even) td{background:#f1f7f8}.CRITICAL{color:#b91c1c;font-weight:700}.HIGH{color:#c2410c;font-weight:700}"
           ".MEDIUM{color:#a16207;font-weight:700}")
    parts = [f"<!doctype html><meta charset=utf-8><title>{html.escape(title)}</title><style>{css}</style><h1>{html.escape(title)}</h1>"]
    for name, head, rows in secs:
        parts.append(f"<h2>{html.escape(name)}</h2><table><tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in head) + "</tr>")
        for r in rows:
            parts.append("<tr>" + "".join(f"<td class='{html.escape(str(c))}'>{html.escape(str(c))}</td>" if str(c) in ("CRITICAL", "HIGH", "MEDIUM")
                                          else f"<td>{html.escape(str(c))}</td>" for c in r) + "</tr>")
        parts.append("</table>")
    return "".join(parts)


def write_reports(outdir: str, scope, snapshot, alerts, assets, chg_base, chg_prev, evaluation=None) -> Dict[str, str]:
    import os
    os.makedirs(outdir, exist_ok=True)
    title = f"Attack-Surface Report - {scope.organisation} (snapshot #{snapshot['id']})"
    secs = build_sections(scope, snapshot, alerts, assets, chg_base, chg_prev, evaluation)
    paths = {}
    for ext, content in (("md", render_markdown(title, secs)), ("html", render_html(title, secs)),
                         ("json", json.dumps({"snapshot": snapshot, "alerts": alerts, "changes_vs_baseline": chg_base,
                                              "changes_vs_previous": chg_prev, "evaluation": evaluation}, indent=2, default=str))):
        p = os.path.join(outdir, f"report_snapshot_{snapshot['id']}.{ext}")
        with open(p, "w") as f:
            f.write(content)
        paths[ext] = p
    return paths
