"""DNS inventory and dangling-record *candidate* detection.

A dangling CNAME candidate is a CNAME whose target no longer exists
(NXDOMAIN).  That is only a candidate: we never test or claim that it is
exploitable, and we never contact the CNAME target (it is outside scope).
"""
from typing import Dict

RECORD_TYPES = ["A", "AAAA", "CNAME", "NS", "MX", "TXT"]

# Hints only - used to word the alert, never to probe the provider.
PROVIDER_HINTS = {
    "s3.amazonaws.com": "AWS S3", "amazonaws.com": "AWS",
    "elasticbeanstalk.com": "AWS Elastic Beanstalk", "cloudfront.net": "AWS CloudFront",
    "azurewebsites.net": "Azure App Service", "cloudapp.azure.com": "Azure VM",
    "blob.core.windows.net": "Azure Blob", "trafficmanager.net": "Azure Traffic Manager",
    "github.io": "GitHub Pages", "herokuapp.com": "Heroku",
    "googleusercontent.com": "Google Cloud", "appspot.com": "Google App Engine",
}


def provider_hint(target: str) -> str:
    t = target.lower().rstrip(".")
    for suffix, name in PROVIDER_HINTS.items():
        if t == suffix or t.endswith("." + suffix):
            return name
    return ""


def collect_dns(guard, resolver, domain: str) -> Dict:
    """Query the record types for one in-scope domain."""
    domain = guard.check_domain(domain)
    records, errors, statuses = {}, [], set()
    for rtype in RECORD_TYPES:
        res = resolver.lookup(domain, rtype)
        statuses.add(res.status)
        if res.status == "OK":
            records[rtype] = res.records
        elif res.status == "ERROR":
            errors.append(f"{rtype}: {res.detail}")
    # a name exists unless every query said NXDOMAIN
    exists = statuses != {"NXDOMAIN"}
    return {"domain": domain, "records": records, "errors": errors, "exists": exists}


def check_dangling(resolver, domain: str, records: Dict) -> Dict:
    """Return a candidate dict, or {} when the CNAME (if any) still resolves."""
    for target in records.get("CNAME", []):
        res = resolver.lookup(target, "A")
        if res.status == "NXDOMAIN":
            hint = provider_hint(target)
            return {
                "domain": domain, "cname_target": target, "provider_hint": hint,
                "confidence": "high" if hint else "medium",
                "reason": f"CNAME target {target} returns NXDOMAIN"
                          + (f" ({hint} naming pattern)" if hint else ""),
            }
        if res.status == "ERROR":
            return {"domain": domain, "cname_target": target, "provider_hint": "",
                    "confidence": "inconclusive",
                    "reason": f"could not resolve CNAME target {target}: {res.detail}"}
    return {}
