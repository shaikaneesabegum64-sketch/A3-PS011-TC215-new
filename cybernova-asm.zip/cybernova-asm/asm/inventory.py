"""SQLite inventory: snapshots, assets and alerts.

Asset types and keys
  domain      <fqdn>                 existence + errors
  dns_record  <fqdn>|<TYPE>          list of values
  host        <host name>            address
  service     <address>:<port>/tcp   state, service, banner, http, tls flag
  tls_cert    <address>:<port>#<sni> certificate facts
"""
import json
import sqlite3
from typing import Dict, List, Optional

from .util import iso, utcnow

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots(
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
  started_at TEXT NOT NULL, finished_at TEXT, scope_ref TEXT,
  is_baseline INTEGER DEFAULT 0, notes TEXT);
CREATE TABLE IF NOT EXISTS assets(
  snapshot_id INTEGER NOT NULL, asset_type TEXT NOT NULL, asset_key TEXT NOT NULL,
  data TEXT NOT NULL, PRIMARY KEY(snapshot_id, asset_type, asset_key));
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER NOT NULL,
  created_at TEXT NOT NULL, rule TEXT NOT NULL, severity TEXT NOT NULL,
  asset_key TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL,
  fingerprint TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',
  fp_reason TEXT, is_new INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS idx_alert_snap ON alerts(snapshot_id);
CREATE TABLE IF NOT EXISTS false_positives(
  fingerprint TEXT PRIMARY KEY, rule TEXT, asset_key TEXT, reason TEXT,
  marked_by TEXT, marked_at TEXT);
"""


class Inventory:
    def __init__(self, path: str):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)

    # ---------------------------------------------------------- snapshots
    def new_snapshot(self, kind: str, scope_ref: str = "", notes: str = "") -> int:
        cur = self.db.execute("INSERT INTO snapshots(kind,started_at,scope_ref,notes) VALUES(?,?,?,?)",
                              (kind, iso(utcnow()), scope_ref, notes))
        self.db.commit()
        return cur.lastrowid

    def finish_snapshot(self, sid: int, baseline: bool = False):
        if baseline:
            self.db.execute("UPDATE snapshots SET is_baseline=0")
        self.db.execute("UPDATE snapshots SET finished_at=?, is_baseline=? WHERE id=?",
                        (iso(utcnow()), 1 if baseline else 0, sid))
        self.db.commit()

    def baseline_id(self) -> Optional[int]:
        r = self.db.execute("SELECT id FROM snapshots WHERE is_baseline=1 ORDER BY id DESC LIMIT 1").fetchone()
        return r["id"] if r else None

    def previous_id(self, before: int) -> Optional[int]:
        r = self.db.execute("SELECT id FROM snapshots WHERE id<? AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 1",
                            (before,)).fetchone()
        return r["id"] if r else None

    def latest_id(self) -> Optional[int]:
        r = self.db.execute("SELECT id FROM snapshots WHERE finished_at IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()
        return r["id"] if r else None

    def snapshot(self, sid: int) -> Dict:
        r = self.db.execute("SELECT * FROM snapshots WHERE id=?", (sid,)).fetchone()
        return dict(r) if r else {}

    # ------------------------------------------------------------- assets
    def put_asset(self, sid: int, asset_type: str, key: str, data: Dict):
        self.db.execute("INSERT OR REPLACE INTO assets VALUES(?,?,?,?)",
                        (sid, asset_type, key, json.dumps(data, sort_keys=True)))

    def commit(self):
        self.db.commit()

    def assets(self, sid: Optional[int]) -> Dict:
        """Return {(asset_type, key): data} for a snapshot."""
        if sid is None:
            return {}
        rows = self.db.execute("SELECT asset_type, asset_key, data FROM assets WHERE snapshot_id=?", (sid,))
        return {(r["asset_type"], r["asset_key"]): json.loads(r["data"]) for r in rows}

    # ------------------------------------------------------------- alerts
    def add_alert(self, sid: int, a: Dict):
        self.db.execute(
            "INSERT INTO alerts(snapshot_id,created_at,rule,severity,asset_key,title,detail,fingerprint,status,fp_reason,is_new)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (sid, iso(utcnow()), a["rule"], a["severity"], a["asset_key"], a["title"],
             json.dumps(a["detail"], sort_keys=True), a["fingerprint"], a.get("status", "open"),
             a.get("fp_reason"), 1 if a.get("is_new", True) else 0))

    def alerts(self, sid: int, status: str = None) -> List[Dict]:
        q, args = "SELECT * FROM alerts WHERE snapshot_id=?", [sid]
        if status:
            q += " AND status=?"; args.append(status)
        rows = self.db.execute(q + " ORDER BY id", args).fetchall()
        out = []
        for r in rows:
            d = dict(r); d["detail"] = json.loads(d["detail"]); out.append(d)
        return out

    def alert_fingerprints(self, sid: Optional[int]) -> set:
        if sid is None:
            return set()
        return {r["fingerprint"] for r in self.db.execute("SELECT fingerprint FROM alerts WHERE snapshot_id=?", (sid,))}

    # ----------------------------------------------------- false positives
    def mark_false_positive(self, fingerprint: str, rule: str, asset_key: str, reason: str, who: str):
        self.db.execute("INSERT OR REPLACE INTO false_positives VALUES(?,?,?,?,?,?)",
                        (fingerprint, rule, asset_key, reason, who, iso(utcnow())))
        self.db.commit()

    def false_positives(self) -> Dict[str, Dict]:
        return {r["fingerprint"]: dict(r) for r in self.db.execute("SELECT * FROM false_positives")}
