"""TLS certificate inventory and validity checks.

One handshake without verification (so expired / self-signed certificates can
still be inspected) plus an optional second handshake with normal verification
to report whether the chain is trusted.  Read-only; nothing is sent after the
handshake.
"""
import hashlib
import socket
import ssl
from datetime import datetime, timezone
from typing import Dict

from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.x509.oid import ExtensionOID, NameOID


def _name_attr(name, oid):
    attrs = name.get_attributes_for_oid(oid)
    return attrs[0].value if attrs else ""


def hostname_matches(hostname: str, names) -> bool:
    h = hostname.lower().rstrip(".")
    for n in names:
        n = n.lower()
        if n == h:
            return True
        if n.startswith("*.") and h.count(".") >= 1 and h.split(".", 1)[1] == n[2:]:
            return True
    return False


def parse_certificate(der: bytes, now: datetime = None) -> Dict:
    now = now or datetime.now(timezone.utc)
    cert = x509.load_der_x509_certificate(der)
    not_after = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after.replace(tzinfo=timezone.utc)
    not_before = getattr(cert, "not_valid_before_utc", None) or cert.not_valid_before.replace(tzinfo=timezone.utc)
    try:
        san = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value \
                  .get_values_for_type(x509.DNSName)
    except x509.ExtensionNotFound:
        san = []
    subject_cn = _name_attr(cert.subject, NameOID.COMMON_NAME)
    return {
        "subject_cn": subject_cn,
        "issuer_cn": _name_attr(cert.issuer, NameOID.COMMON_NAME),
        "san": sorted(san),
        "not_before": not_before.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "not_after": not_after.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "days_remaining": (not_after - now).days,
        "expired": not_after < now,
        "not_yet_valid": not_before > now,
        "self_signed": cert.subject == cert.issuer,
        "fingerprint_sha256": hashlib.sha256(der).hexdigest(),
        "serial": format(cert.serial_number, "x"),
    }


def check_tls(guard, throttle, address: str, port: int, settings: dict, sni: str) -> Dict:
    """Fetch and evaluate the certificate served at address:port for server name `sni`."""
    guard.check_endpoint(address, port)
    ct, rt = settings["connect_timeout"], settings["read_timeout"]
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    throttle.wait()
    try:
        with socket.create_connection((address, port), timeout=ct) as raw:
            raw.settimeout(rt)
            with ctx.wrap_socket(raw, server_hostname=sni) as s:
                der = s.getpeercert(binary_form=True)
                version = s.version()
    except (ssl.SSLError, OSError, socket.timeout) as e:
        return {"error": f"{e.__class__.__name__}: {e}"}
    info = parse_certificate(der)
    names = info["san"] or ([info["subject_cn"]] if info["subject_cn"] else [])
    info["hostname_match"] = hostname_matches(sni, names)
    info["tls_version"] = version
    info["sni"] = sni

    # second handshake with verification => is the chain trusted?
    vctx = ssl.create_default_context()
    vctx.check_hostname = False
    throttle.wait()
    try:
        with socket.create_connection((address, port), timeout=ct) as raw:
            raw.settimeout(rt)
            with vctx.wrap_socket(raw, server_hostname=sni):
                info["chain_trusted"] = True
    except ssl.SSLCertVerificationError as e:
        info["chain_trusted"] = False
        info["chain_error"] = e.verify_message
    except (ssl.SSLError, OSError, socket.timeout):
        info["chain_trusted"] = None
    return info
