"""Cybernova - Authorised Attack-Surface Inventory and Change Monitor (AIORI-3 PS-011)."""
__version__ = "1.0.0"
