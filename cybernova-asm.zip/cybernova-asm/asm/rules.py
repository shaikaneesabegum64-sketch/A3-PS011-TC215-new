"""Alert rules: turn a snapshot (+ baseline + changes) into actionable alerts.

Rules
  CERT_EXPIRED               certificate past its not_after date            critical
  CERT_EXPIRING_SOON         expires within warn/critical window            medium/high
  CERT_HOSTNAME_MISMATCH     served name not covered by certificate         medium
  CERT_SELF_SIGNED           self-signed certificate                        low
  CERT_CHANGED               certificate replaced since baseline            low
  UNEXPECTED_SERVICE         open service not in baseline or expected list  medium (high if risky)
  SERVICE_DISAPPEARED        baseline service no longer open                low
  DNS_RECORD_CHANGED         DNS record added/changed/removed vs baseline   low-high
  DOMAIN_NOT_RESOLVING       domain that existed in baseline no longer does medium
  DANGLING_CNAME_CANDIDATE   CNAME target is NXDOMAIN (candidate only)      medium/high
"""
from typing import Dict, List

from .util import sha1

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

# Seeded-issue category -> rule that detects it (used by the evaluator).
SEEDED_RULES = {
    "expired_certificate": "CERT_EXPIRED",
    "unexpected_service": "UNEXPECTED_SERVICE",
    "dangling_dns": "DANGLING_CNAME_CANDIDATE",
}


def _alert(rule, severity, key, title, detail, discriminator=""):
    return {"rule": rule, "severity": severity, "asset_key": key, "title": title,
            "detail": detail, "fingerprint": sha1(rule, key, discriminator)}


def evaluate_rules(scope, current: Dict, baseline: Dict, changes: List[Dict]) -> List[Dict]:
    s = scope.settings
    expected = {h.address: set(h.expected_ports) for h in scope.hosts}
    alerts = []

    # ---- certificate state rules (no baseline needed)
    # One certificate served for several server names is reported once per endpoint.
    groups = {}
    for (atype, key), d in sorted(current.items()):
        if atype == "tls_cert" and "error" not in d:
            groups.setdefault((key.split("#")[0], d["fingerprint_sha256"]), []).append((key, d))
    for (endpoint, _fp), members in groups.items():
        d = members[0][1]
        names = sorted({m[1].get("sni", "") for m in members})
        if d.get("expired"):
            alerts.append(_alert("CERT_EXPIRED", "critical", endpoint,
                                 f"TLS certificate on {endpoint} expired on {d['not_after']}",
                                 {"not_after": d["not_after"], "days_remaining": d["days_remaining"],
                                  "subject_cn": d["subject_cn"], "issuer_cn": d["issuer_cn"], "served_for": names},
                                 d["not_after"]))
        elif d["days_remaining"] <= s["cert_warn_days"]:
            sev = "high" if d["days_remaining"] <= s["cert_critical_days"] else "medium"
            alerts.append(_alert("CERT_EXPIRING_SOON", sev, endpoint,
                                 f"TLS certificate on {endpoint} expires in {d['days_remaining']} days",
                                 {"not_after": d["not_after"], "days_remaining": d["days_remaining"], "served_for": names},
                                 d["not_after"]))
        if d.get("self_signed") and not d.get("expired"):
            alerts.append(_alert("CERT_SELF_SIGNED", "low", endpoint,
                                 f"Self-signed certificate on {endpoint}",
                                 {"subject_cn": d["subject_cn"], "served_for": names}, d["fingerprint_sha256"]))
        for key, m in members:
            if m.get("hostname_match") is False:
                alerts.append(_alert("CERT_HOSTNAME_MISMATCH", "medium", key,
                                     f"Certificate on {endpoint} does not cover '{m.get('sni')}'",
                                     {"sni": m.get("sni"), "san": m["san"], "subject_cn": m["subject_cn"]}, m.get("sni", "")))

    # ---- DNS dangling candidates (state based)
    for (atype, key), d in current.items():
        if atype == "dangling":
            sev = {"high": "high", "medium": "medium"}.get(d["confidence"], "low")
            alerts.append(_alert("DANGLING_CNAME_CANDIDATE", sev, key,
                                 f"Potential dangling DNS record: {key} -> {d['cname_target']}",
                                 {**d, "note": "Candidate only - not verified as exploitable"}, d["cname_target"]))

    # ---- baseline dependent rules
    if baseline:
        base_open = {k[1] for k, v in baseline.items() if k[0] == "service" and v.get("state") == "open"}
        for (atype, key), d in current.items():
            if atype != "service" or d.get("state") != "open" or key in base_open:
                continue
            port = d["port"]
            if port in expected.get(d["address"], set()):
                continue
            sev = "high" if d.get("risky") else "medium"
            alerts.append(_alert("UNEXPECTED_SERVICE", sev, key,
                                 f"Unexpected {d['service']} service open on {key}",
                                 {"service": d["service"], "banner": d.get("banner", ""),
                                  "http": d.get("http", {}), "risky_service": d.get("risky", False)}, d["service"]))

        for c in changes:
            t, key = c["asset_type"], c["key"]
            if t == "service" and c["change"] in ("removed", "modified") and c["before"] and c["before"].get("state") == "open":
                still_open = c["after"] and c["after"].get("state") == "open"
                if not still_open:
                    alerts.append(_alert("SERVICE_DISAPPEARED", "low", key,
                                         f"Service on {key} is no longer open", c["before"]))
            elif t == "dns_record":
                rtype = key.split("|")[1]
                sev = {"NS": "high", "A": "medium", "AAAA": "medium", "CNAME": "medium"}.get(rtype, "low")
                alerts.append(_alert("DNS_RECORD_CHANGED", sev, key,
                                     f"DNS {rtype} record {c['change']} for {key.split('|')[0]}",
                                     {"change": c["change"], "before": c["before"], "after": c["after"]},
                                     str(c["after"])))
            elif t == "domain" and c["change"] == "modified" and c["before"].get("exists") and not c["after"].get("exists"):
                alerts.append(_alert("DOMAIN_NOT_RESOLVING", "medium", key,
                                     f"{key} existed at baseline but no longer resolves", {}))
            elif t == "tls_cert" and c["change"] == "modified" and "fingerprint_sha256" in c.get("fields", []):
                alerts.append(_alert("CERT_CHANGED", "low", key,
                                     f"Certificate on {key} changed since baseline",
                                     {"before": c["before"], "after": c["after"]}, c["after"]["fingerprint_sha256"]))

    alerts.sort(key=lambda a: (SEVERITY_ORDER[a["severity"]], a["rule"], a["asset_key"]))
    return alerts
