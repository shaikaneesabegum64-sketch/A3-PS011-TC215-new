"""Minimal DNS client (standard library only) plus a static resolver for labs/tests.

Only passive record lookups are performed: A, AAAA, CNAME, NS, MX, TXT.
"""
import ipaddress
import json
import random
import socket
import struct
from dataclasses import dataclass, field
from typing import List

QTYPES = {"A": 1, "NS": 2, "CNAME": 5, "MX": 15, "TXT": 16, "AAAA": 28}
QTYPE_NAMES = {v: k for k, v in QTYPES.items()}


@dataclass
class Lookup:
    status: str                       # OK | NODATA | NXDOMAIN | ERROR
    records: List[str] = field(default_factory=list)
    detail: str = ""


# ---------------------------------------------------------------- wire format
def build_query(name: str, qtype: int, qid: int) -> bytes:
    header = struct.pack("!HHHHHH", qid, 0x0100, 1, 0, 0, 0)
    qname = b"".join(bytes([len(p)]) + p.encode("idna") for p in name.rstrip(".").split(".")) + b"\x00"
    return header + qname + struct.pack("!HH", qtype, 1)


def read_name(data: bytes, offset: int):
    labels, jumped, end, hops = [], False, offset, 0
    while True:
        if offset >= len(data):
            raise ValueError("truncated name")
        length = data[offset]
        if length & 0xC0 == 0xC0:
            ptr = ((length & 0x3F) << 8) | data[offset + 1]
            if not jumped:
                end = offset + 2
            offset, jumped = ptr, True
            hops += 1
            if hops > 20:
                raise ValueError("compression loop")
            continue
        offset += 1
        if length == 0:
            if not jumped:
                end = offset
            break
        labels.append(data[offset:offset + length].decode("ascii", "replace"))
        offset += length
    return ".".join(labels).lower(), end


def parse_response(data: bytes):
    """Return (rcode, truncated, [(type_name, value), ...])."""
    qid, flags, qd, an, _, _ = struct.unpack("!HHHHHH", data[:12])
    rcode, truncated = flags & 0xF, bool(flags & 0x0200)
    off = 12
    for _ in range(qd):
        _, off = read_name(data, off)
        off += 4
    answers = []
    for _ in range(an):
        _, off = read_name(data, off)
        rtype, _, _, rdlen = struct.unpack("!HHIH", data[off:off + 10])
        off += 10
        rdata = data[off:off + rdlen]
        t = QTYPE_NAMES.get(rtype)
        if t == "A" and rdlen == 4:
            answers.append((t, str(ipaddress.IPv4Address(rdata))))
        elif t == "AAAA" and rdlen == 16:
            answers.append((t, str(ipaddress.IPv6Address(rdata))))
        elif t in ("NS", "CNAME"):
            answers.append((t, read_name(data, off)[0]))
        elif t == "MX":
            pref = struct.unpack("!H", rdata[:2])[0]
            answers.append((t, f"{pref} {read_name(data, off + 2)[0]}"))
        elif t == "TXT":
            parts, i = [], 0
            while i < len(rdata):
                ln = rdata[i]
                parts.append(rdata[i + 1:i + 1 + ln].decode("utf-8", "replace"))
                i += 1 + ln
            answers.append((t, "".join(parts)))
        off += rdlen
    return rcode, truncated, answers


# ------------------------------------------------------------------ resolvers
def system_nameservers():
    try:
        with open("/etc/resolv.conf") as f:
            ns = [l.split()[1] for l in f if l.startswith("nameserver") and len(l.split()) > 1]
            if ns:
                return ns
    except OSError:
        pass
    return []


class Resolver:
    """Recursive-resolver client over UDP with TCP fallback."""

    def __init__(self, nameservers=None, timeout=3.0, retries=2, throttle=None):
        self.nameservers = nameservers or system_nameservers()
        self.timeout, self.retries, self.throttle = timeout, retries, throttle
        if not self.nameservers:
            raise RuntimeError("No DNS nameserver configured (set resolver.nameservers in the scope file)")

    def _udp(self, ns, packet):
        with socket.socket(socket.AF_INET6 if ":" in ns else socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(self.timeout)
            s.sendto(packet, (ns, 53))
            return s.recv(4096)

    def _tcp(self, ns, packet):
        with socket.create_connection((ns, 53), timeout=self.timeout) as s:
            s.sendall(struct.pack("!H", len(packet)) + packet)
            ln = struct.unpack("!H", s.recv(2))[0]
            buf = b""
            while len(buf) < ln:
                chunk = s.recv(ln - len(buf))
                if not chunk:
                    break
                buf += chunk
            return buf

    def lookup(self, name: str, rtype: str) -> Lookup:
        qid = random.randrange(65536)
        packet = build_query(name, QTYPES[rtype], qid)
        last = "no response"
        for ns in self.nameservers:
            for _ in range(self.retries):
                if self.throttle:
                    self.throttle.wait()
                try:
                    resp = self._udp(ns, packet)
                    rcode, trunc, answers = parse_response(resp)
                    if trunc:
                        rcode, _, answers = parse_response(self._tcp(ns, packet))
                except (OSError, ValueError, struct.error) as e:
                    last = f"{ns}: {e}"
                    continue
                if rcode == 3:
                    return Lookup("NXDOMAIN")
                if rcode != 0:
                    return Lookup("ERROR", detail=f"rcode {rcode} from {ns}")
                recs = sorted({v for t, v in answers if t == rtype})
                return Lookup("OK", recs) if recs else Lookup("NODATA")
        return Lookup("ERROR", detail=last)


class StaticResolver:
    """Zone-file resolver for the offline lab and unit tests.

    zone = {"name": {"A": ["1.2.3.4"], "CNAME": ["other.name"], ...}}
    A name that is absent from the zone answers NXDOMAIN.
    """

    def __init__(self, zone: dict):
        self.zone = {k.lower(): v for k, v in zone.items()}

    @classmethod
    def from_file(cls, path):
        return cls(json.load(open(path)))

    def lookup(self, name: str, rtype: str) -> Lookup:
        node = self.zone.get(name.lower().rstrip("."))
        if node is None:
            return Lookup("NXDOMAIN")
        recs = sorted(node.get(rtype, []))
        return Lookup("OK", recs) if recs else Lookup("NODATA")


def build_resolver(cfg: dict, settings: dict, throttle=None, base_dir="."):
    import os
    if cfg.get("type") == "static":
        path = cfg["zone_file"]
        if not os.path.isabs(path):
            path = os.path.join(base_dir, path)
        return StaticResolver.from_file(path)
    return Resolver(cfg.get("nameservers"), timeout=settings.get("connect_timeout", 3.0), throttle=throttle)
