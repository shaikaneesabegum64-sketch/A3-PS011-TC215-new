"""Seeded-issue detection results and false-positive analysis.

The organiser (or our own lab) seeds known issues.  We compare what the
monitor reported with that ground truth:

  true positive   alert that matches a seeded issue
  false negative  seeded issue with no matching alert
  false positive  alert of a seeded class that matches no seeded issue
                  (reported separately as 'dismissed after review' when an
                  analyst marked it, or 'unreviewed' otherwise)
"""
import json
from typing import Dict, List

from .rules import SEEDED_RULES


def _endpoint(key: str) -> str:
    return key.split("#")[0]


def load_seeded(path: str) -> List[Dict]:
    return json.load(open(path))["seeded"]


def evaluate(alerts: List[Dict], seeded: List[Dict]) -> Dict:
    class_rules = set(SEEDED_RULES.values())
    candidates = [a for a in alerts if a["rule"] in class_rules]

    results, matched_keys = [], set()
    for s in seeded:
        rule = SEEDED_RULES[s["type"]]
        hits = [a for a in candidates if a["rule"] == rule and _endpoint(a["asset_key"]) == _endpoint(s["asset_key"])]
        for h in hits:
            matched_keys.add(h["id"])
        results.append({"id": s["id"], "type": s["type"], "asset_key": s["asset_key"],
                        "detected": bool(hits), "severity": hits[0]["severity"] if hits else "",
                        "alert": hits[0]["title"] if hits else ""})

    extras = [a for a in candidates if a["id"] not in matched_keys]
    reviewed = [a for a in extras if a["status"] == "false_positive"]
    unreviewed = [a for a in extras if a["status"] != "false_positive"]

    tp = sum(1 for r in results if r["detected"])
    fn = len(results) - tp
    fp_raw = len({(a["rule"], _endpoint(a["asset_key"])) for a in extras})
    fp_active = len({(a["rule"], _endpoint(a["asset_key"])) for a in unreviewed})
    prec = lambda t, f: round(t / (t + f), 3) if (t + f) else 1.0
    return {
        "seeded_total": len(seeded), "true_positives": tp, "false_negatives": fn,
        "false_positives_raw": fp_raw, "false_positives_after_review": fp_active,
        "recall": round(tp / len(seeded), 3) if seeded else 1.0,
        "precision_raw": prec(tp, fp_raw),
        "precision_after_review": prec(tp, fp_active),
        "seeded_results": results,
        "false_positive_analysis": [
            {"asset_key": a["asset_key"], "rule": a["rule"], "title": a["title"],
             "outcome": "dismissed after review" if a["status"] == "false_positive" else "UNREVIEWED - triage needed",
             "reason": a.get("fp_reason") or ""} for a in reviewed + unreviewed],
    }
