"""Command line interface:  python -m asm <command> ..."""
import argparse
import json
import os
import sys

from .evaluate import evaluate, load_seeded
from .inventory import Inventory
from .report import write_reports
from .scanner import Scanner
from .scheduler import run_schedule
from .scope import ScopeError, load_scope
from .util import sha1


def _print_run(result):
    active = [a for a in result["alerts"] if a["status"] != "false_positive"]
    print(f"Snapshot #{result['snapshot_id']}: {result['assets']} assets, {len(active)} active alerts, "
          f"{len(result['changes_vs_baseline'])} changes vs baseline, {len(result['changes_vs_previous'])} vs previous scan")
    for a in active:
        print(f"  [{a['severity'].upper():8}] {a['rule']:26} {a['title']}")


def _report(args, scanner=None, result=None):
    scope = load_scope(args.scope)
    inv = Inventory(args.db)
    sid = args.snapshot or inv.latest_id()
    if not sid:
        sys.exit("No completed snapshot yet - run 'baseline' first.")
    snap = inv.snapshot(sid)
    alerts = inv.alerts(sid)
    base_id, prev_id = inv.baseline_id(), inv.previous_id(sid)
    from .diff import diff_inventories
    cur = inv.assets(sid)
    chg_b = diff_inventories(inv.assets(base_id), cur) if base_id and base_id != sid else []
    chg_p = diff_inventories(inv.assets(prev_id), cur) if prev_id else []
    evaluation = evaluate(alerts, load_seeded(args.seeded)) if getattr(args, "seeded", None) else None
    paths = write_reports(args.out, scope, snap, alerts, cur, chg_b, chg_p, evaluation)
    print("Reports written:", ", ".join(paths.values()))
    if evaluation:
        print(f"Seeded issues: {evaluation['true_positives']}/{evaluation['seeded_total']} detected, "
              f"precision {evaluation['precision_raw']} raw / {evaluation['precision_after_review']} after review")


def main(argv=None):
    p = argparse.ArgumentParser(prog="asm", description="Authorised attack-surface inventory and change monitor")
    p.add_argument("--scope", default="config/scope.json", help="written, organiser-approved scope file")
    p.add_argument("--db", default="data/inventory.db")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("validate-scope", help="check the scope file and approval window")
    sub.add_parser("baseline", help="scan and store the trusted baseline inventory")
    sub.add_parser("scan", help="scan, compare with baseline/previous scan, raise alerts")

    r = sub.add_parser("report", help="write Markdown/HTML/JSON report for a snapshot")
    r.add_argument("--snapshot", type=int); r.add_argument("--out", default="reports")
    r.add_argument("--seeded", help="seeded-issues JSON to include detection results and FP analysis")

    s = sub.add_parser("schedule", help="repeat scans on an interval")
    s.add_argument("--every", type=float, default=60, help="minutes between scans")
    s.add_argument("--runs", type=int, default=0, help="stop after N runs (0 = forever)")

    f = sub.add_parser("fp", help="mark an alert as a reviewed false positive")
    f.add_argument("--rule", required=True); f.add_argument("--asset", required=True)
    f.add_argument("--reason", required=True); f.add_argument("--by", default="analyst")
    f.add_argument("--discriminator", default="", help="extra value used when the alert was generated (e.g. service name)")

    a = p.parse_args(argv)
    os.makedirs(os.path.dirname(a.db) or ".", exist_ok=True)
    try:
        if a.cmd == "validate-scope":
            sc = load_scope(a.scope)
            print(f"OK: {sc.organisation} - {len(sc.domains)} domains, {len(sc.hosts)} hosts, "
                  f"approval {sc.reference} by {sc.approved_by}, valid until {sc.valid_until:%Y-%m-%d}")
        elif a.cmd in ("baseline", "scan"):
            _print_run(Scanner(a.scope, a.db).run(a.cmd))
        elif a.cmd == "report":
            _report(a)
        elif a.cmd == "schedule":
            run_schedule(lambda: Scanner(a.scope, a.db), a.every, a.runs, _print_run)
        elif a.cmd == "fp":
            inv = Inventory(a.db)
            latest = inv.latest_id()
            matches = [x for x in inv.alerts(latest) if x["rule"] == a.rule and x["asset_key"].startswith(a.asset)] if latest else []
            if not matches:
                sys.exit("No matching alert in the latest snapshot - check --rule and --asset.")
            for m in matches:
                inv.mark_false_positive(m["fingerprint"], m["rule"], m["asset_key"], a.reason, a.by)
                print(f"Marked false positive: {m['rule']} {m['asset_key']}")
    except ScopeError as e:
        sys.exit(f"SCOPE ERROR: {e}")


if __name__ == "__main__":
    main()
