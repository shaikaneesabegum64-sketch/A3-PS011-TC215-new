"""Inventory comparison (the scheduled change-detection step)."""
from typing import Dict, List

# Only these fields count as a "change"; volatile fields (days_remaining,
# banners with timestamps, ...) are ignored so scans do not raise noise.
STABLE_FIELDS = {
    "domain": ["exists"],
    "dns_record": ["values"],
    "host": ["address"],
    "service": ["state", "service", "tls", "server"],
    "tls_cert": ["fingerprint_sha256", "not_after", "subject_cn", "issuer_cn", "san"],
}


def _view(asset_type: str, data: Dict) -> Dict:
    view = {f: data.get(f) for f in STABLE_FIELDS.get(asset_type, [])}
    if asset_type == "service":
        view["server"] = (data.get("http") or {}).get("server", "")
    return view


def diff_inventories(old: Dict, new: Dict) -> List[Dict]:
    """old/new are {(asset_type, key): data}.  Returns a list of change dicts."""
    changes = []
    for k in sorted(set(old) | set(new)):
        atype, key = k
        if k not in old:
            if atype == "service" and new[k].get("state") != "open":
                continue                      # a newly seen *closed* port is not a change
            changes.append({"change": "added", "asset_type": atype, "key": key, "before": None, "after": _view(atype, new[k])})
        elif k not in new:
            changes.append({"change": "removed", "asset_type": atype, "key": key, "before": _view(atype, old[k]), "after": None})
        else:
            b, a = _view(atype, old[k]), _view(atype, new[k])
            if b != a:
                fields = [f for f in a if a[f] != b[f]]
                changes.append({"change": "modified", "asset_type": atype, "key": key,
                                "before": b, "after": a, "fields": fields})
    return changes
