"""Service exposure checks - exactly four documented, non-intrusive checks.

  CHECK 1  TCP connect     full TCP handshake only; tells open / closed / filtered.
  CHECK 2  Banner read     passively read what the service volunteers (nothing sent).
  CHECK 3  TLS handshake   attempt a TLS handshake to see if the port speaks TLS.
  CHECK 4  HTTP HEAD       a single "HEAD /" request on ports that speak HTTP/TLS;
                           records the status line and Server header only.

No exploit payloads, no credentials, no fuzzing, no brute force.  Every call is
authorised through ScopeGuard.check_endpoint() first and rate limited.
"""
import socket
import ssl
from typing import Dict

# Service hints by well-known port - only used when the service gives no banner.
PORT_HINTS = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http", 110: "pop3",
    143: "imap", 443: "https", 445: "smb", 1433: "mssql", 3306: "mysql", 3389: "rdp",
    5432: "postgres", 5900: "vnc", 6379: "redis", 8080: "http", 8443: "https", 27017: "mongodb",
}
# Services that should rarely be exposed on the public internet.
RISKY_SERVICES = {"telnet", "ftp", "smb", "rdp", "vnc", "mysql", "postgres", "mssql",
                  "redis", "mongodb"}


def identify_banner(data: bytes) -> str:
    """Map a passively received banner to a service name ('' if unknown)."""
    if not data:
        return ""
    text = data[:200].decode("latin-1", "replace")
    low = text.lower()
    if text.startswith("SSH-"):
        return "ssh"
    if data[0] == 0xFF:                      # Telnet IAC
        return "telnet"
    if text.startswith("220") and "ftp" in low:
        return "ftp"
    if text.startswith("220") and ("smtp" in low or "mail" in low):
        return "smtp"
    if text.startswith("+OK"):
        return "pop3"
    if text.startswith("* OK") and "imap" in low:
        return "imap"
    if len(data) > 5 and data[4] == 0x0A and data[5:6].isdigit():   # MySQL greeting
        return "mysql"
    if text.startswith("HTTP/"):
        return "http"
    return ""


def _printable(b: bytes, limit=80) -> str:
    return "".join(chr(c) if 32 <= c < 127 else "." for c in b[:limit]).strip()


def check_port(guard, throttle, address: str, port: int, settings: dict, sni: str = None) -> Dict:
    guard.check_endpoint(address, port)
    ct, rt = settings["connect_timeout"], settings["read_timeout"]
    result = {"address": address, "port": port, "state": "closed", "banner": "",
              "tls": False, "http": {}, "service": "", "checks": []}

    # CHECK 1 - TCP connect
    throttle.wait()
    try:
        sock = socket.create_connection((address, port), timeout=ct)
    except ConnectionRefusedError:
        result["checks"].append("tcp_connect:refused")
        return result
    except (socket.timeout, TimeoutError):
        result["state"] = "filtered"
        result["checks"].append("tcp_connect:timeout")
        return result
    except OSError as e:
        result["state"] = "filtered"
        result["checks"].append(f"tcp_connect:error:{e.__class__.__name__}")
        return result
    result["state"] = "open"
    result["checks"].append("tcp_connect:open")

    # CHECK 2 - passive banner read
    banner = b""
    try:
        sock.settimeout(rt)
        banner = sock.recv(256)
    except (socket.timeout, OSError):
        pass
    finally:
        sock.close()
    result["checks"].append("banner:" + ("received" if banner else "none"))
    result["banner"] = _printable(banner)
    svc = identify_banner(banner)

    # CHECK 3 - TLS handshake (fresh connection, no verification: we only inspect)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    tls_sock = None
    if not svc:
        throttle.wait()
        try:
            raw = socket.create_connection((address, port), timeout=ct)
            raw.settimeout(rt)
            tls_sock = ctx.wrap_socket(raw, server_hostname=sni or None)
            result["tls"] = True
            result["tls_version"] = tls_sock.version()
            result["checks"].append("tls_handshake:ok")
        except (ssl.SSLError, OSError, socket.timeout):
            result["checks"].append("tls_handshake:no")
            tls_sock = None

    # CHECK 4 - HTTP HEAD (only where HTTP is plausible)
    plausible = result["tls"] or svc == "http" or PORT_HINTS.get(port) in ("http", "https") or (not svc and not banner)
    if plausible:
        throttle.wait()
        try:
            conn = tls_sock
            if conn is None:
                conn = socket.create_connection((address, port), timeout=ct)
                conn.settimeout(rt)
            host = sni or address
            conn.sendall(f"HEAD / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\nUser-Agent: cybernova-asm/1.0 (authorised inventory)\r\n\r\n".encode())
            resp = conn.recv(1024).decode("latin-1", "replace")
            if resp.startswith("HTTP/"):
                lines = resp.split("\r\n")
                server = next((l.split(":", 1)[1].strip() for l in lines if l.lower().startswith("server:")), "")
                result["http"] = {"status_line": lines[0], "server": server}
                result["checks"].append("http_head:ok")
                svc = "https" if result["tls"] else "http"
            else:
                result["checks"].append("http_head:not_http")
        except (OSError, socket.timeout, ssl.SSLError):
            result["checks"].append("http_head:error")
        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass
    elif tls_sock:
        tls_sock.close()

    if not svc and result["tls"]:
        svc = "tls"
    result["service"] = svc or PORT_HINTS.get(port, "unknown")
    result["risky"] = result["service"] in RISKY_SERVICES
    return result
