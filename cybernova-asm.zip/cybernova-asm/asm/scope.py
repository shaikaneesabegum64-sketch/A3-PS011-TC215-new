"""Authorised scope: the single source of truth for what may be touched.

Rules enforced here (PS-011 requirement: "use only written,
organiser-approved target scope"):
  * the scope file must carry an approval record with a validity window;
  * at most 20 domains and 10 hosts;
  * every network operation must call ScopeGuard.* first - anything not
    listed in the scope raises ScopeError and is never contacted;
  * ports are limited to the ports listed per host.
"""
import ipaddress
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List

MAX_DOMAINS = 20
MAX_HOSTS = 10
HOSTNAME_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?\.)*[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")

DEFAULT_SETTINGS = {
    "delay_ms": 200,            # minimum gap between any two network operations
    "max_workers": 4,           # parallel workers (hard cap 8)
    "connect_timeout": 3.0,
    "read_timeout": 2.0,
    "cert_warn_days": 30,
    "cert_critical_days": 7,
}


class ScopeError(Exception):
    """Raised when a target or the scope file itself is not authorised."""


@dataclass
class Host:
    name: str
    address: str
    ports: List[int]
    expected_ports: List[int] = field(default_factory=list)


@dataclass
class Scope:
    organisation: str
    approved_by: str
    reference: str
    valid_from: datetime
    valid_until: datetime
    domains: List[str]
    hosts: List[Host]
    settings: Dict
    resolver: Dict

    def host_addresses(self):
        return {h.address for h in self.hosts}


def _parse_date(value, end_of_day=False):
    try:
        d = datetime.strptime(value, "%Y-%m-%d")
    except Exception:
        raise ScopeError(f"Invalid approval date '{value}' (use YYYY-MM-DD)")
    if end_of_day:
        d = d.replace(hour=23, minute=59, second=59)
    return d.replace(tzinfo=timezone.utc)


def _valid_target(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return bool(HOSTNAME_RE.match(value.lower()))


def load_scope(path: str, now: datetime = None) -> Scope:
    now = now or datetime.now(timezone.utc)
    try:
        raw = json.load(open(path))
    except FileNotFoundError:
        raise ScopeError(f"Scope file not found: {path}. Scanning needs a written scope file.")
    except json.JSONDecodeError as e:
        raise ScopeError(f"Scope file is not valid JSON: {e}")

    appr = raw.get("approval") or {}
    for k in ("approved_by", "reference", "valid_from", "valid_until"):
        if not appr.get(k):
            raise ScopeError(f"Scope approval record is missing '{k}'")
    valid_from = _parse_date(appr["valid_from"])
    valid_until = _parse_date(appr["valid_until"], end_of_day=True)
    if now < valid_from:
        raise ScopeError(f"Scope approval is not valid until {appr['valid_from']}")
    if now > valid_until:
        raise ScopeError(f"Scope approval expired on {appr['valid_until']}; get it renewed in writing")

    domains = [d.strip().lower().rstrip(".") for d in raw.get("domains", [])]
    if not domains and not raw.get("hosts"):
        raise ScopeError("Scope lists no domains or hosts")
    if len(domains) > MAX_DOMAINS:
        raise ScopeError(f"Scope lists {len(domains)} domains; maximum is {MAX_DOMAINS}")
    if len(set(domains)) != len(domains):
        raise ScopeError("Scope contains duplicate domains")
    for d in domains:
        if not HOSTNAME_RE.match(d):
            raise ScopeError(f"Invalid domain in scope: {d}")

    hosts = []
    for h in raw.get("hosts", []):
        name, addr = h.get("name"), h.get("address")
        if not name or not addr or not _valid_target(addr):
            raise ScopeError(f"Host entry needs a valid 'name' and 'address': {h}")
        ports = sorted({int(p) for p in h.get("ports", [])})
        if not ports or any(p < 1 or p > 65535 for p in ports):
            raise ScopeError(f"Host {name}: 'ports' must list valid ports (1-65535)")
        hosts.append(Host(name, addr, ports, sorted({int(p) for p in h.get("expected_ports", [])})))
    if len(hosts) > MAX_HOSTS:
        raise ScopeError(f"Scope lists {len(hosts)} hosts; maximum is {MAX_HOSTS}")
    if len({h.name for h in hosts}) != len(hosts):
        raise ScopeError("Scope contains duplicate host names")

    settings = dict(DEFAULT_SETTINGS)
    settings.update(raw.get("settings", {}))
    settings["max_workers"] = max(1, min(8, int(settings["max_workers"])))

    return Scope(raw.get("organisation", "unnamed"), appr["approved_by"], appr["reference"],
                 valid_from, valid_until, domains, hosts, settings,
                 raw.get("resolver", {"type": "system"}))


class ScopeGuard:
    """Gatekeeper called before every DNS query or connection."""

    def __init__(self, scope: Scope):
        self.scope = scope
        self._domains = set(scope.domains)
        self._ports = {h.address: set(h.ports) for h in scope.hosts}

    def check_domain(self, name: str) -> str:
        n = name.strip().lower().rstrip(".")
        if n not in self._domains:
            raise ScopeError(f"'{name}' is not in the approved domain scope - refusing")
        return n

    def check_endpoint(self, address: str, port: int):
        if address not in self._ports:
            raise ScopeError(f"Address '{address}' is not an approved host - refusing")
        if port not in self._ports[address]:
            raise ScopeError(f"Port {port} is not approved for {address} - refusing")

    def is_scoped_address(self, address: str) -> bool:
        return address in self._ports
