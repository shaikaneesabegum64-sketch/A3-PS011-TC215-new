"""Scheduled change detection.

`run_schedule` repeats a scan every N minutes; each run is compared with the
baseline and the previous scan.  For production you can instead call
`python -m asm scan` from cron / a systemd timer (see README).
"""
import time

from .scope import ScopeError


def run_schedule(make_scanner, interval_minutes: float, runs: int = 0, on_result=None):
    """make_scanner() builds a fresh Scanner each cycle so an expired scope
    approval stops scanning immediately.  runs=0 means run until interrupted."""
    done = 0
    while True:
        try:
            result = make_scanner().run("scan")
        except ScopeError as e:
            print(f"[scheduler] STOPPED - scope not authorised: {e}")
            return
        if on_result:
            on_result(result)
        done += 1
        if runs and done >= runs:
            return
        time.sleep(max(1.0, interval_minutes * 60))
