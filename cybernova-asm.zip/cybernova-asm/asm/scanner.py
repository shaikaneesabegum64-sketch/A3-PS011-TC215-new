"""Scan orchestration: discovery -> inventory -> diff -> alerts."""
import os
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Optional

from .diff import diff_inventories
from .dns_checks import check_dangling, collect_dns
from .dnsclient import build_resolver
from .inventory import Inventory
from .port_checks import check_port
from .rules import evaluate_rules
from .scope import ScopeGuard, load_scope
from .tls_checks import check_tls
from .util import Throttle


class Scanner:
    def __init__(self, scope_path: str, db_path: str):
        self.scope_path = scope_path
        self.scope = load_scope(scope_path)            # raises ScopeError if not authorised
        self.guard = ScopeGuard(self.scope)
        self.inv = Inventory(db_path)
        s = self.scope.settings
        self.throttle = Throttle(s["delay_ms"] / 1000.0)
        self.resolver = build_resolver(self.scope.resolver, s, self.throttle,
                                       base_dir=os.path.dirname(os.path.abspath(scope_path)))

    # ---------------------------------------------------------------- discovery
    def _dns_task(self, domain):
        info = collect_dns(self.guard, self.resolver, domain)
        dangling = check_dangling(self.resolver, domain, info["records"]) if info["exists"] else {}
        return domain, info, dangling

    def _host_task(self, host):
        out = []
        for port in host.ports:
            res = check_port(self.guard, self.throttle, host.address, port, self.scope.settings, sni=host.name)
            out.append((host, res))
        return out

    def _tls_task(self, address, port, sni):
        return address, port, sni, check_tls(self.guard, self.throttle, address, port, self.scope.settings, sni)

    def discover(self, sid: int) -> Dict:
        """Run all checks and store assets for snapshot `sid`.  Returns {(type,key): data}."""
        workers = self.scope.settings["max_workers"]
        scoped_addr_to_host = {h.address: h for h in self.scope.hosts}
        domain_ips = {}

        with ThreadPoolExecutor(max_workers=workers) as ex:
            # --- DNS inventory
            for domain, info, dangling in ex.map(self._dns_task, self.scope.domains):
                self.inv.put_asset(sid, "domain", domain, {"exists": info["exists"], "errors": info["errors"]})
                for rtype, vals in info["records"].items():
                    self.inv.put_asset(sid, "dns_record", f"{domain}|{rtype}", {"values": vals})
                if dangling:
                    self.inv.put_asset(sid, "dangling", domain, dangling)
                # remember which approved hosts this domain points at (for SNI cert checks)
                for ip in info["records"].get("A", []) + info["records"].get("AAAA", []):
                    if self.guard.is_scoped_address(ip):
                        domain_ips.setdefault(ip, []).append(domain)

            # --- service exposure on approved hosts
            tls_jobs = []
            for host_results in ex.map(self._host_task, self.scope.hosts):
                for host, r in host_results:
                    self.inv.put_asset(sid, "host", host.name, {"address": host.address})
                    key = f"{r['address']}:{r['port']}/tcp"
                    data = {k: v for k, v in r.items()}
                    data["host"] = host.name
                    self.inv.put_asset(sid, "service", key, data)
                    if r["state"] == "open" and r["tls"]:
                        for sni in [host.name] + domain_ips.get(host.address, []):
                            tls_jobs.append((host.address, r["port"], sni))

            # --- TLS certificates (host name + any approved domain pointing at the host)
            for address, port, sni, info in ex.map(lambda j: self._tls_task(*j), tls_jobs):
                self.inv.put_asset(sid, "tls_cert", f"{address}:{port}#{sni}", info)
        self.inv.commit()
        return self.inv.assets(sid)

    # -------------------------------------------------------------------- scans
    def run(self, kind: str = "scan") -> Dict:
        """kind='baseline' stores the trusted inventory; kind='scan' compares and alerts."""
        is_base = kind == "baseline"
        sid = self.inv.new_snapshot(kind, self.scope.reference)
        current = self.discover(sid)

        base_id = None if is_base else self.inv.baseline_id()
        prev_id = self.inv.previous_id(sid)
        baseline = self.inv.assets(base_id)
        previous = self.inv.assets(prev_id)
        changes_vs_base = diff_inventories(baseline, current) if baseline else []
        changes_vs_prev = diff_inventories(previous, current) if previous else []

        alerts = evaluate_rules(self.scope, current, baseline if not is_base else {}, changes_vs_base)
        fps = self.inv.false_positives()
        prev_fprints = self.inv.alert_fingerprints(prev_id)
        for a in alerts:
            a["status"], a["fp_reason"] = "open", None
            fp = fps.get(a["fingerprint"])
            if fp:
                a["status"], a["fp_reason"] = "false_positive", fp["reason"]
            a["is_new"] = a["fingerprint"] not in prev_fprints
            self.inv.add_alert(sid, a)
        self.inv.finish_snapshot(sid, baseline=is_base)
        return {"snapshot_id": sid, "baseline_id": base_id, "previous_id": prev_id,
                "alerts": alerts, "changes_vs_baseline": changes_vs_base,
                "changes_vs_previous": changes_vs_prev, "assets": len(current)}
