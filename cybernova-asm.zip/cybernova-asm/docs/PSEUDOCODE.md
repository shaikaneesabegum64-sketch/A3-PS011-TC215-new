# Pseudocode - Prototype demonstration snippet (PS-011)

```text
LOAD scope_file
IF approval missing OR today outside [valid_from, valid_until]  -> STOP
IF domains > 20 OR hosts > 10                                   -> STOP
guard = ScopeGuard(scope)          # every network call must pass through guard

FUNCTION scan(kind):                       # kind = baseline | scan
    snapshot = inventory.new_snapshot(kind)

    # 1. DNS inventory and dangling-record candidates
    FOR domain IN scope.domains:
        guard.check_domain(domain)
        records = lookup(domain, [A, AAAA, CNAME, NS, MX, TXT])
        store dns_record assets
        FOR target IN records.CNAME:
            IF lookup(target, A) == NXDOMAIN:
                store dangling CANDIDATE(domain, target)     # never claimed exploitable

    # 2. Exposed services - four documented checks per approved port
    FOR host IN scope.hosts:
        FOR port IN host.ports:
            guard.check_endpoint(host.address, port)
            state  = tcp_connect()                           # check 1
            banner = passive_banner_read()                   # check 2
            tls    = tls_handshake_probe()                   # check 3
            http   = http_head_request()                     # check 4 (HEAD only)
            store service asset(state, service, banner, tls, http)

    # 3. TLS certificates for every open TLS port (SNI = host + approved domains)
    FOR each open TLS port:
        cert = fetch_certificate()
        store tls_cert asset(subject, san, not_after, fingerprint, ...)

    # 4. Change detection
    baseline = inventory.baseline_snapshot()
    changes  = diff(baseline, current)       # added / removed / modified, stable fields only

    # 5. Alerts
    FOR cert IN current.certs:    IF cert.expired            -> ALERT CERT_EXPIRED (critical)
    FOR svc  IN current.services: IF svc.open AND svc NOT IN baseline
                                     AND svc.port NOT IN host.expected_ports
                                                             -> ALERT UNEXPECTED_SERVICE
    FOR c    IN dangling.candidates:                         -> ALERT DANGLING_CNAME_CANDIDATE
    FOR c    IN changes WHERE type == dns_record:            -> ALERT DNS_RECORD_CHANGED

    # 6. False-positive handling
    FOR alert IN alerts:
        IF alert.fingerprint IN analyst_false_positive_list: alert.status = false_positive

    inventory.save(snapshot, alerts)
    RETURN alerts, changes

SCHEDULE: every N minutes -> scan("scan") -> write Markdown/HTML/JSON report
EVALUATE: compare alerts with seeded issues -> recall, precision, FP analysis
```
