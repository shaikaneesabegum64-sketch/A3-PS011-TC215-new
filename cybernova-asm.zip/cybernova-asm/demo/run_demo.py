"""End-to-end offline demonstration of the PS-011 system.

    python demo/run_demo.py

Story
  1. Clean lab -> baseline inventory.
  2. Organiser 'seeds' issues: expired certificate, unexpected MySQL service,
     two dangling CNAME candidates, plus a benign maintenance SSH service
     (a deliberate false positive) and a DNS change.
  3. Scheduled comparison detects them, we triage the false positive,
     then reports + seeded-issue evaluation are generated.
  4. A scope-violation attempt is refused.
"""
import json
import os
import sys
from datetime import date, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from asm.evaluate import evaluate, load_seeded                      # noqa: E402
from asm.inventory import Inventory                                   # noqa: E402
from asm.report import write_reports                                  # noqa: E402
from asm.scanner import Scanner                                       # noqa: E402
from asm.scope import ScopeError, load_scope                          # noqa: E402
from asm.cli import _print_run                                        # noqa: E402
from asm.diff import diff_inventories                                 # noqa: E402
from lab_sim import LabServer, MYSQL_GREETING, SSH_BANNER, make_cert, workdir   # noqa: E402

P_HTTP, P_TLS, P_EXPIRED, P_SSH, P_MYSQL = 18080, 18443, 19443, 12222, 13306

ZONE_P1 = {
    "app.lab.test": {"A": ["127.0.0.1"]},
    "www.lab.test": {"CNAME": ["app.lab.test"]},
    "old.lab.test": {"CNAME": ["assets.cdn.lab.test"]},
    "assets.cdn.lab.test": {"A": ["127.0.0.1"]},
    "blob.lab.test": {"CNAME": ["labstore.blob.core.windows.net"]},
    "labstore.blob.core.windows.net": {"A": ["127.0.0.1"]},
}


def banner(t):
    print(f"\n{'=' * 8} {t} {'=' * 8}")


def main():
    work = workdir()
    today = date.today()
    scope = {
        "organisation": "AIORI-3 Lab Portfolio (offline demo)",
        "approval": {"approved_by": "Organiser (demo)", "reference": "DEMO-PS011-001",
                     "valid_from": str(today - timedelta(days=1)), "valid_until": str(today + timedelta(days=30))},
        "domains": ["app.lab.test", "www.lab.test", "old.lab.test", "blob.lab.test"],
        "hosts": [{"name": "lab-web1", "address": "127.0.0.1",
                   "ports": [P_HTTP, P_TLS, P_EXPIRED, P_SSH, P_MYSQL], "expected_ports": [P_HTTP, P_TLS, P_EXPIRED]}],
        "settings": {"delay_ms": 20, "max_workers": 3, "connect_timeout": 1.5, "read_timeout": 0.6},
        "resolver": {"type": "static", "zone_file": "zone.json"},
    }
    zone_path, scope_path, db = (os.path.join(work, n) for n in ("zone.json", "scope.json", "inventory.db"))
    json.dump(scope, open(scope_path, "w"), indent=2)
    json.dump(ZONE_P1, open(zone_path, "w"), indent=2)
    print("Working directory:", work)

    good_c, good_k = make_cert("lab-web1", ["lab-web1", "app.lab.test", "www.lab.test"], -30, 300, work)
    bad_c, bad_k = make_cert("lab-web1", ["lab-web1", "app.lab.test"], -400, -10, work)
    servers = [LabServer(P_HTTP, "http"), LabServer(P_TLS, "tls-http", certfile=good_c, keyfile=good_k)]

    banner("PHASE 1 - baseline of the clean lab")
    _print_run(Scanner(scope_path, db).run("baseline"))

    banner("PHASE 2 - issues are seeded into the lab")
    servers += [LabServer(P_EXPIRED, "tls-http", certfile=bad_c, keyfile=bad_k),
                LabServer(P_MYSQL, "banner", banner=MYSQL_GREETING),
                LabServer(P_SSH, "banner", banner=SSH_BANNER)]
    zone2 = dict(ZONE_P1)
    zone2.pop("assets.cdn.lab.test")                       # old.lab.test now dangles
    zone2.pop("labstore.blob.core.windows.net")            # blob.lab.test now dangles
    zone2["app.lab.test"] = {"A": ["127.0.0.1", "127.0.0.9"]}   # DNS change (127.0.0.9 is NOT in scope -> never scanned)
    json.dump(zone2, open(zone_path, "w"), indent=2)
    seeded_path = os.path.join(work, "seeded.json")
    json.dump({"seeded": [
        {"id": "S1", "type": "expired_certificate", "asset_key": f"127.0.0.1:{P_EXPIRED}"},
        {"id": "S2", "type": "unexpected_service", "asset_key": f"127.0.0.1:{P_MYSQL}/tcp"},
        {"id": "S3", "type": "dangling_dns", "asset_key": "old.lab.test"},
        {"id": "S4", "type": "dangling_dns", "asset_key": "blob.lab.test"}]}, open(seeded_path, "w"), indent=2)

    banner("PHASE 3 - scheduled comparison run")
    _print_run(Scanner(scope_path, db).run("scan"))

    banner("PHASE 4 - analyst triage: SSH on the maintenance port is approved")
    inv = Inventory(db)
    for a in inv.alerts(inv.latest_id()):
        if a["rule"] == "UNEXPECTED_SERVICE" and a["asset_key"].endswith(f":{P_SSH}/tcp"):
            inv.mark_false_positive(a["fingerprint"], a["rule"], a["asset_key"],
                                    "Approved temporary maintenance SSH (change ticket CHG-1042)", "analyst")
            print("Marked false positive:", a["title"])
    result = Scanner(scope_path, db).run("scan")
    _print_run(result)

    banner("PHASE 5 - reports and seeded-issue evaluation")
    sid = result["snapshot_id"]
    ev = evaluate(inv.alerts(sid), load_seeded(seeded_path))
    cur = inv.assets(sid)
    paths = write_reports(os.path.join(work, "reports"), load_scope(scope_path), inv.snapshot(sid), inv.alerts(sid), cur,
                          diff_inventories(inv.assets(inv.baseline_id()), cur), result["changes_vs_previous"], ev)
    for r in ev["seeded_results"]:
        print(f"  {r['id']} {r['type']:20} {'DETECTED' if r['detected'] else 'MISSED':9} {r['asset_key']}")
    print(f"  recall={ev['recall']}  precision(raw)={ev['precision_raw']}  precision(after review)={ev['precision_after_review']}")
    print("  reports:", ", ".join(paths.values()))

    banner("SCOPE ENFORCEMENT - attempt to touch an unapproved target")
    sc = Scanner(scope_path, db)
    for addr, port in (("8.8.8.8", 53), ("127.0.0.1", 22)):
        try:
            sc.guard.check_endpoint(addr, port)
        except ScopeError as e:
            print("  REFUSED:", e)
    for s in servers:
        s.close()


if __name__ == "__main__":
    main()
