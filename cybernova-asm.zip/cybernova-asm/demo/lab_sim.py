"""Offline lab: tiny local servers used to demonstrate and test the monitor.

Everything binds to 127.0.0.1 - nothing leaves the machine.
"""
import datetime
import os
import socket
import ssl
import tempfile
import threading

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


def make_cert(cn, san, days_from_now_start, days_from_now_end, outdir):
    """Self-signed cert valid between now+start and now+end days (negative = past)."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now + datetime.timedelta(days=days_from_now_start))
            .not_valid_after(now + datetime.timedelta(days=days_from_now_end))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName(s) for s in san]), critical=False)
            .sign(key, hashes.SHA256()))
    cpath = os.path.join(outdir, f"{cn}-{abs(days_from_now_end)}.crt")
    kpath = os.path.join(outdir, f"{cn}-{abs(days_from_now_end)}.key")
    open(cpath, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    open(kpath, "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                              serialization.NoEncryption()))
    return cpath, kpath


class LabServer:
    """kind: 'http' | 'tls-http' | 'banner'."""

    def __init__(self, port, kind, banner=b"", certfile=None, keyfile=None, server_header="LabHTTPD/1.0"):
        self.port, self.kind, self.banner, self.server_header = port, kind, banner, server_header
        self.sock = socket.socket()
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", port))
        self.sock.listen(16)
        self.ctx = None
        if kind == "tls-http":
            self.ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            self.ctx.load_cert_chain(certfile, keyfile)
        self._stop = False
        threading.Thread(target=self._loop, daemon=True).start()

    def _handle(self, conn):
        try:
            conn.settimeout(2)
            if self.kind == "banner":
                conn.sendall(self.banner)
                conn.recv(256)
                return
            if self.ctx:
                conn = self.ctx.wrap_socket(conn, server_side=True)
            conn.recv(1024)
            conn.sendall(f"HTTP/1.1 200 OK\r\nServer: {self.server_header}\r\nContent-Length: 0\r\n\r\n".encode())
        except (OSError, ssl.SSLError):
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass

    def _loop(self):
        while not self._stop:
            try:
                conn, _ = self.sock.accept()
            except OSError:
                return
            threading.Thread(target=self._handle, args=(conn,), daemon=True).start()

    def close(self):
        self._stop = True
        self.sock.close()


MYSQL_GREETING = b"\x4a\x00\x00\x00\x0a5.7.40-lab\x00" + b"\x00" * 20
SSH_BANNER = b"SSH-2.0-OpenSSH_9.6 lab-maintenance\r\n"


def workdir():
    return tempfile.mkdtemp(prefix="asm-lab-")
