import json

from asm.diff import diff_inventories
from asm.rules import evaluate_rules
from asm.scope import load_scope


def scope(tmp_path):
    p = tmp_path / "s.json"
    p.write_text(json.dumps({"approval": {"approved_by": "o", "reference": "r", "valid_from": "2020-01-01", "valid_until": "2099-01-01"},
                             "domains": ["a.lab.test"],
                             "hosts": [{"name": "h", "address": "10.0.0.5", "ports": [22, 80, 3306], "expected_ports": [80]}]}))
    return load_scope(str(p))


def svc(port, state="open", service="http", risky=False):
    return ("service", f"10.0.0.5:{port}/tcp"), {"address": "10.0.0.5", "port": port, "state": state, "service": service,
                                                  "tls": False, "http": {}, "banner": "", "risky": risky}


def cert(days, expired=False):
    return ("tls_cert", "10.0.0.5:443#h"), {"expired": expired, "days_remaining": days, "not_after": "2030-01-01T00:00:00Z",
                                            "subject_cn": "h", "issuer_cn": "h", "san": ["h"], "self_signed": False,
                                            "hostname_match": True, "fingerprint_sha256": "ab", "sni": "h"}


def test_diff_ignores_volatile_fields():
    k, d = cert(100)
    k2, d2 = cert(99)
    assert diff_inventories({k: d}, {k2: d2}) == []


def test_diff_detects_changes_and_ignores_new_closed_ports():
    base = dict([svc(80)])
    cur = dict([svc(80), svc(3306, service="mysql", risky=True), svc(22, state="closed")])
    ch = diff_inventories(base, cur)
    assert [(c["change"], c["key"]) for c in ch] == [("added", "10.0.0.5:3306/tcp")]


def test_rules(tmp_path):
    sc = scope(tmp_path)
    base = dict([svc(80)])
    cur = dict([svc(80), svc(3306, service="mysql", risky=True), svc(22, service="ssh")])
    cur.update([cert(-5, expired=True)])
    alerts = evaluate_rules(sc, cur, base, diff_inventories(base, cur))
    rules = {(a["rule"], a["asset_key"]): a["severity"] for a in alerts}
    assert rules[("UNEXPECTED_SERVICE", "10.0.0.5:3306/tcp")] == "high"
    assert rules[("UNEXPECTED_SERVICE", "10.0.0.5:22/tcp")] == "medium"
    assert rules[("CERT_EXPIRED", "10.0.0.5:443")] == "critical"
    # expected port 80 never alerts; without a baseline unexpected-service is skipped
    assert not any(a["asset_key"].endswith(":80/tcp") for a in alerts)
    assert not [a for a in evaluate_rules(sc, cur, {}, []) if a["rule"] == "UNEXPECTED_SERVICE"]
