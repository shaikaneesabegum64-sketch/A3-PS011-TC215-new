import json

import pytest

from asm.scope import MAX_DOMAINS, ScopeError, ScopeGuard, load_scope


def write(tmp_path, **over):
    cfg = {"approval": {"approved_by": "Org", "reference": "REF-1", "valid_from": "2020-01-01", "valid_until": "2099-12-31"},
           "domains": ["a.lab.test"], "hosts": [{"name": "h1", "address": "10.0.0.5", "ports": [22, 443]}]}
    cfg.update(over)
    p = tmp_path / "scope.json"
    p.write_text(json.dumps(cfg))
    return str(p)


def test_valid_scope_and_guard(tmp_path):
    g = ScopeGuard(load_scope(write(tmp_path)))
    assert g.check_domain("A.lab.test.") == "a.lab.test"
    g.check_endpoint("10.0.0.5", 443)
    with pytest.raises(ScopeError):
        g.check_domain("evil.example.com")
    with pytest.raises(ScopeError):
        g.check_endpoint("10.0.0.6", 443)
    with pytest.raises(ScopeError):
        g.check_endpoint("10.0.0.5", 8080)


def test_limits(tmp_path):
    with pytest.raises(ScopeError):
        load_scope(write(tmp_path, domains=[f"d{i}.lab.test" for i in range(MAX_DOMAINS + 1)]))
    hosts = [{"name": f"h{i}", "address": f"10.0.0.{i}", "ports": [80]} for i in range(11)]
    with pytest.raises(ScopeError):
        load_scope(write(tmp_path, hosts=hosts))


def test_missing_or_expired_approval(tmp_path):
    with pytest.raises(ScopeError):
        load_scope(str(tmp_path / "nope.json"))
    with pytest.raises(ScopeError):
        load_scope(write(tmp_path, approval={"approved_by": "x", "reference": "r", "valid_from": "2020-01-01", "valid_until": "2020-02-01"}))
    with pytest.raises(ScopeError):
        load_scope(write(tmp_path, approval={"approved_by": "x"}))
