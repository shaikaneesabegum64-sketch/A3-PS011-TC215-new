import run_demo


def test_demo_runs_end_to_end(capsys):
    run_demo.main()
    out = capsys.readouterr().out
    assert "recall=1.0" in out and "precision(after review)=1.0" in out
    assert out.count("REFUSED") == 2
