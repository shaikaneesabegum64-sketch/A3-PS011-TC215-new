import json

import pytest

from asm.port_checks import check_port, identify_banner
from asm.scope import ScopeError, ScopeGuard, load_scope
from asm.tls_checks import check_tls, hostname_matches
from asm.util import Throttle
from lab_sim import LabServer, MYSQL_GREETING, SSH_BANNER, make_cert, workdir

PORTS = [17001, 17002, 17003, 17004]
CLOSED = 17005


@pytest.fixture(scope="module")
def lab(tmp_path_factory):
    d = workdir()
    good = make_cert("h1", ["h1"], -1, 90, d)
    old = make_cert("h1", ["h1"], -400, -3, d)
    servers = [LabServer(PORTS[0], "http"), LabServer(PORTS[1], "tls-http", certfile=good[0], keyfile=good[1]),
               LabServer(PORTS[2], "tls-http", certfile=old[0], keyfile=old[1]), LabServer(PORTS[3], "banner", banner=MYSQL_GREETING)]
    p = tmp_path_factory.mktemp("s") / "scope.json"
    p.write_text(json.dumps({"approval": {"approved_by": "o", "reference": "r", "valid_from": "2020-01-01", "valid_until": "2099-01-01"},
                             "domains": ["a.lab.test"], "hosts": [{"name": "h1", "address": "127.0.0.1", "ports": PORTS + [CLOSED]}]}))
    sc = load_scope(str(p))
    yield ScopeGuard(sc), sc.settings
    for s in servers:
        s.close()


def test_port_checks(lab):
    g, st = lab
    t = Throttle(0)
    http = check_port(g, t, "127.0.0.1", PORTS[0], st)
    assert http["state"] == "open" and http["service"] == "http" and http["http"]["server"] == "LabHTTPD/1.0"
    tls = check_port(g, t, "127.0.0.1", PORTS[1], st, sni="h1")
    assert tls["tls"] and tls["service"] == "https"
    mysql = check_port(g, t, "127.0.0.1", PORTS[3], st)
    assert mysql["service"] == "mysql" and mysql["risky"]
    assert check_port(g, t, "127.0.0.1", CLOSED, st)["state"] == "closed"


def test_out_of_scope_refused(lab):
    g, st = lab
    with pytest.raises(ScopeError):
        check_port(g, Throttle(0), "127.0.0.1", 22, st)
    with pytest.raises(ScopeError):
        check_port(g, Throttle(0), "192.0.2.1", PORTS[0], st)


def test_tls_expiry(lab):
    g, st = lab
    t = Throttle(0)
    ok = check_tls(g, t, "127.0.0.1", PORTS[1], st, "h1")
    assert not ok["expired"] and ok["hostname_match"] and ok["self_signed"] and ok["chain_trusted"] is False
    bad = check_tls(g, t, "127.0.0.1", PORTS[2], st, "h1")
    assert bad["expired"] and bad["days_remaining"] < 0
    assert check_tls(g, t, "127.0.0.1", PORTS[2], st, "other.test")["hostname_match"] is False


def test_helpers():
    assert hostname_matches("a.lab.test", ["*.lab.test"]) and not hostname_matches("lab.test", ["*.lab.test"])
    assert identify_banner(SSH_BANNER) == "ssh" and identify_banner(MYSQL_GREETING) == "mysql" and identify_banner(b"") == ""
