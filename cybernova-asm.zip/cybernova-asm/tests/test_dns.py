import struct

from asm.dns_checks import check_dangling, provider_hint
from asm.dnsclient import QTYPES, StaticResolver, build_query, parse_response, read_name


def name_bytes(n):
    return b"".join(bytes([len(p)]) + p.encode() for p in n.split(".")) + b"\x00"


def test_query_roundtrip_and_cname_response():
    q = build_query("old.lab.test", QTYPES["CNAME"], 77)
    assert struct.unpack("!H", q[:2])[0] == 77
    # craft a response: question + one CNAME answer using a compression pointer
    target = name_bytes("gone.example.net")
    hdr = struct.pack("!HHHHHH", 77, 0x8180, 1, 1, 0, 0)
    question = name_bytes("old.lab.test") + struct.pack("!HH", 5, 1)
    answer = b"\xc0\x0c" + struct.pack("!HHIH", 5, 1, 60, len(target)) + target
    rcode, trunc, answers = parse_response(hdr + question + answer)
    assert (rcode, trunc, answers) == (0, False, [("CNAME", "gone.example.net")])
    assert read_name(name_bytes("a.b"), 0)[0] == "a.b"


def test_nxdomain_rcode():
    hdr = struct.pack("!HHHHHH", 1, 0x8183, 1, 0, 0, 0)
    rcode, _, answers = parse_response(hdr + name_bytes("x.test") + struct.pack("!HH", 1, 1))
    assert rcode == 3 and answers == []


def test_dangling_detection():
    r = StaticResolver({"old.lab.test": {"CNAME": ["labstore.blob.core.windows.net"]},
                        "ok.lab.test": {"CNAME": ["alive.lab.test"]}, "alive.lab.test": {"A": ["1.2.3.4"]}})
    c = check_dangling(r, "old.lab.test", {"CNAME": ["labstore.blob.core.windows.net"]})
    assert c["confidence"] == "high" and c["provider_hint"] == "Azure Blob"
    assert check_dangling(r, "ok.lab.test", {"CNAME": ["alive.lab.test"]}) == {}
    assert provider_hint("x.example.com") == ""
