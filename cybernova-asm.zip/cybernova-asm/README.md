# Cybernova - Authorised Attack-Surface Inventory and Change Monitor

**AIORI-3 Hackathon - PS-011 (Cybersecurity)** | Team Cybernova | A3-PS011-TC215
Shaik Aneesa Begum, Namburi Naga Venkata Likhitha Sri, Karumuri Sireesha

A scope-controlled tool that catalogues public DNS records, TLS certificates and
exposed services for a lab portfolio, keeps a baseline inventory, runs scheduled
comparisons and raises alerts for **expired certificates**, **unexpected services**
and **potential dangling DNS records**.

## Requirement coverage

| PS-011 requirement | Where it is implemented |
|---|---|
| Monitor up to 20 domains and 10 hosts | `asm/scope.py` enforces `MAX_DOMAINS=20`, `MAX_HOSTS=10` |
| Only written, organiser-approved scope | Scope file needs an approval record + validity window; `ScopeGuard` refuses anything not listed (`asm/scope.py`) |
| 4 documented port checks | `asm/port_checks.py`: TCP connect, banner read, TLS handshake, HTTP HEAD |
| Track domains, DNS, TLS certs, services | `asm/dns_checks.py`, `asm/tls_checks.py`, `asm/inventory.py` |
| Scheduled inventory comparisons | `asm/diff.py`, `asm/scheduler.py` (or cron) |
| Detect expired certs / unexpected services / dangling DNS | `asm/rules.py` |
| Report false positives | `asm/evaluate.py`, `python -m asm fp ...` |
| Alert and change reports | `asm/report.py` (Markdown, HTML, JSON) |
| No exploitation / unrestricted scanning / exploitability claims | Connect-and-read only; rate limiter; dangling records labelled *candidate*; CNAME targets are never contacted |

## Quick start

```bash
pip install -r requirements.txt          # only 'cryptography' is needed at runtime

# 1. Run the complete offline demo (local lab on 127.0.0.1, nothing leaves your machine)
python demo/run_demo.py

# 2. Run the tests
python -m pytest -q tests
```

## Using it on the real, approved lab

```bash
cp config/scope.example.json config/scope.json     # fill in ONLY what the organiser approved in writing
python -m asm validate-scope
python -m asm baseline                             # trusted starting inventory
python -m asm scan                                 # compare with baseline + previous scan, raise alerts
python -m asm report --out reports --seeded config/seeded_issues.json
python -m asm fp --rule UNEXPECTED_SERVICE --asset 203.0.113.10:22 --reason "approved maintenance"
python -m asm schedule --every 60                  # or use cron below
```

Cron example (hourly): `0 * * * * cd /path/to/cybernova-asm && python -m asm scan`

`config/scope.json` is git-ignored on purpose: keep the real target list out of
public history.  The resolver defaults to the system nameserver
(`"resolver": {"type": "system"}`); use `"nameservers": ["..."]` to pin one.

## Architecture

```
scope.json --> ScopeGuard --> [DNS lookups] [Port checks x4] [TLS cert fetch]
                                   \              |               /
                                    +--> SQLite inventory (snapshots) <--+
                                                  |
                             diff vs baseline / previous scan
                                                  |
                       rules -> alerts -> false-positive filter -> reports
```

## Safety design

* Every DNS query and connection passes `ScopeGuard`; out-of-scope targets raise `ScopeError`.
* An expired or missing approval stops scanning immediately (including in scheduled mode).
* Global rate limit (`delay_ms`), capped workers (max 8), short timeouts.
* Port checks send nothing except a single `HEAD /` on HTTP-capable ports.
* CNAME targets belong to third parties: we only ask DNS whether they exist, never connect.
* Dangling records are *candidates* based on NXDOMAIN; the report says so.

## Project layout

```
asm/        scope, dnsclient, dns_checks, port_checks, tls_checks, inventory,
            diff, rules, scanner, scheduler, evaluate, report, cli
config/     scope.example.json, seeded_issues.example.json
demo/       lab_sim.py (local servers), run_demo.py (end-to-end story)
docs/       PSEUDOCODE.md (prototype pseudocode snippet for the mentor demo)
tests/      pytest suite
```

## Deliverables checklist (from the problem statement)

- [ ] Private GitHub repo named after the team; add `aiori-hackathon` as collaborator, then transfer ownership
- [ ] PDF documentation uploaded to the repo (follow *Proposed-structure-hackathon.pdf*)
- [ ] Prototype demonstration with pseudocode snippet (`docs/PSEUDOCODE.md`, `demo/run_demo.py`)
