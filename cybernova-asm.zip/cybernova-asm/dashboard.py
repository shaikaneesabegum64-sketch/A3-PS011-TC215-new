"""
Cybernova ASM - Professional Web Dashboard & SOC Interface
AIORI-3 Cybersecurity Hackathon | Problem Statement PS-011
Team: Cybernova | Code: A3-PS011-TC215
Members: Shaik Aneesa Begum, Namburi Naga Venkata Likhitha Sri, Karumuri Sireesha
"""

import os
import sys
import json
import sqlite3
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from datetime import datetime
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

PORT = 8080

def get_db_data():
    """Extracts live inventory, alerts, and assets from SQLite or generates demo state."""
    db_path = PROJECT_ROOT / "inventory.db"
    
    # If no db exists yet, check temp or run demo simulation
    if not db_path.exists():
        # Check standard temp location or subdirectories
        temp_dbs = list(Path(os.environ.get("TEMP", "/tmp")).glob("asm-lab-*/inventory.db"))
        if temp_dbs:
            db_path = temp_dbs[-1]
            
    if db_path.exists():
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            
            # Snapshots
            cur.execute("SELECT * FROM snapshots ORDER BY id DESC")
            snapshots = [dict(r) for r in cur.fetchall()]
            latest_id = snapshots[0]["id"] if snapshots else 1
            
            # Alerts
            cur.execute("SELECT * FROM alerts WHERE snapshot_id = ? ORDER BY id DESC", (latest_id,))
            alerts = [dict(r) for r in cur.fetchall()]
            if not alerts and snapshots:
                # get all alerts from latest non-empty snapshot
                cur.execute("SELECT * FROM alerts ORDER BY id DESC")
                alerts = [dict(r) for r in cur.fetchall()]
                
            # Assets
            cur.execute("SELECT * FROM assets WHERE snapshot_id = ?", (latest_id,))
            assets = [dict(r) for r in cur.fetchall()]
            
            conn.close()
            return format_dashboard_payload(snapshots, alerts, assets)
        except Exception as e:
            print(f"[!] Error reading SQLite DB: {e}")

    # Fallback to rich built-in demo dataset matching PS-011 seeded requirements
    return get_default_demo_payload()


def format_dashboard_payload(snapshots, alerts, assets):
    """Formats raw database rows into rich dashboard JSON."""
    dns_records = []
    tls_certs = []
    services = []
    
    for a in assets:
        atype = a.get("asset_type")
        akey = a.get("asset_key")
        raw_data = a.get("data", "{}")
        try:
            data = json.loads(raw_data) if isinstance(raw_data, str) else raw_data
        except Exception:
            data = {}
            
        if atype == "dns_record":
            dns_records.append({
                "key": akey,
                "domain": akey.split("|")[0] if "|" in akey else akey,
                "type": akey.split("|")[1] if "|" in akey else "A",
                "values": data.get("values", []),
                "is_dangling": any("dangling" in al.get("rule", "").lower() for al in alerts if akey in al.get("asset_key", ""))
            })
        elif atype == "tls_cert":
            tls_certs.append({
                "target": akey,
                "common_name": data.get("subject_cn") or data.get("cn") or akey,
                "san": data.get("san", []),
                "days_left": data.get("days_until_expiry", 0),
                "expiry": data.get("not_after") or data.get("expiry_iso", "2026-10-27"),
                "is_expired": data.get("is_expired", False) or (data.get("days_until_expiry", 0) <= 0)
            })
        elif atype == "service":
            services.append({
                "endpoint": akey,
                "host": akey.split(":")[0] if ":" in akey else akey,
                "port": int(akey.split(":")[1].split("/")[0]) if ":" in akey else 80,
                "service": data.get("service", "tcp"),
                "banner": data.get("banner", "-"),
                "unexpected": any("unexpected" in al.get("rule", "").lower() for al in alerts if akey in al.get("asset_key", ""))
            })

    # If assets were empty in that snapshot, enrich with standard lab set
    if not dns_records and not services:
        return get_default_demo_payload()

    return {
        "snapshots": snapshots,
        "alerts": alerts,
        "dns_records": dns_records,
        "tls_certs": tls_certs,
        "services": services,
        "meta": {
            "team_name": "Cybernova",
            "team_code": "A3-PS011-TC215",
            "project_title": "PS011-Authorised Attack-Surface Inventory and Change Monitor",
            "members": ["Shaik Aneesa Begum", "Namburi Naga Venkata Likhitha Sri", "Karumuri Sireesha"],
            "hackathon": "AIORI 3 Hackathon",
            "date": "1-11-2026",
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        }
    }


def get_default_demo_payload():
    """Generates complete PS-011 seeded lab dataset."""
    return {
        "meta": {
            "team_name": "Cybernova",
            "team_code": "A3-PS011-TC215",
            "project_title": "PS011-Authorised Attack-Surface Inventory and Change Monitor",
            "members": ["Shaik Aneesa Begum", "Namburi Naga Venkata Likhitha Sri", "Karumuri Sireesha"],
            "hackathon": "AIORI 3 Hackathon",
            "date": "1-11-2026",
            "timestamp": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        },
        "snapshots": [
            {"id": 3, "kind": "scan", "started_at": "2026-11-01T04:42:00Z", "finished_at": "2026-11-01T04:42:04Z", "notes": "Scheduled comparison after lab seeded drift"},
            {"id": 2, "kind": "scan", "started_at": "2026-11-01T04:30:00Z", "finished_at": "2026-11-01T04:30:05Z", "notes": "Change detection run"},
            {"id": 1, "kind": "baseline", "started_at": "2026-11-01T04:00:00Z", "finished_at": "2026-11-01T04:00:06Z", "notes": "Clean lab gold baseline"}
        ],
        "alerts": [
            {
                "id": 1,
                "severity": "CRITICAL",
                "rule": "EXPIRED_CERTIFICATE",
                "asset_key": "docs.lab03.aiori.org:443",
                "title": "Expired TLS Certificate Detected",
                "detail": "Target presents an EXPIRED TLS certificate (expired 5 days ago on 2026-10-27). Trust chain broken.",
                "status": "open",
                "confidence": "VERIFIED (100%)",
                "seeded": True
            },
            {
                "id": 2,
                "severity": "HIGH",
                "rule": "UNEXPECTED_SERVICE_EXPOSED",
                "asset_key": "10.0.1.11:8080/tcp",
                "title": "Unapproved Port 8080 Exposed",
                "detail": "Host 10.0.1.11 has exposed unexpected open service on port 8080. Banner: Werkzeug/2.2.2 Python Debug Server.",
                "status": "open",
                "confidence": "VERIFIED (95%)",
                "seeded": True
            },
            {
                "id": 3,
                "severity": "HIGH",
                "rule": "POTENTIAL_DANGLING_DNS",
                "asset_key": "static.lab04.aiori.org",
                "title": "Potential Dangling CNAME to Cloud S3",
                "detail": "CNAME points to canonical 'aiori-test-bucket-orphaned.s3.amazonaws.com' (AWS S3) returning NXDOMAIN. Passive inspection verified.",
                "status": "open",
                "confidence": "HIGH (90%)",
                "seeded": True
            },
            {
                "id": 4,
                "severity": "HIGH",
                "rule": "POTENTIAL_DANGLING_DNS",
                "asset_key": "blob.lab.test",
                "title": "Dangling CNAME to Azure Storage",
                "detail": "CNAME points to 'labstore.blob.core.windows.net' which returns non-allocated status on canonical lookup.",
                "status": "open",
                "confidence": "HIGH (90%)",
                "seeded": True
            },
            {
                "id": 5,
                "severity": "MEDIUM",
                "rule": "DNS_RECORD_ALTERED",
                "asset_key": "app.lab.test|A",
                "title": "DNS A Record Modified",
                "detail": "A record set modified: Added '127.0.0.9'. Out of approved scanning scope -> ignored by prober.",
                "status": "open",
                "confidence": "HIGH",
                "seeded": False
            },
            {
                "id": 6,
                "severity": "INFO",
                "rule": "CERTIFICATE_MODIFIED",
                "asset_key": "docs.lab03.aiori.org:443",
                "title": "Certificate Metadata Drift",
                "detail": "TLS Certificate serial & expiry timestamp modified from baseline record.",
                "status": "open",
                "confidence": "HIGH",
                "seeded": False
            },
            {
                "id": 7,
                "severity": "SUPPRESSED",
                "rule": "POTENTIAL_DANGLING_DNS",
                "asset_key": "portal.lab02.aiori.org",
                "title": "Suppressed Internal Split-Horizon DNS",
                "detail": "Canonical target 'internal-proxy.corp.internal' uses private split-horizon naming. Non-routable & non-hijackable over public DNS.",
                "status": "false_positive",
                "fp_reason": "Private split-horizon domain. Non-exploitable publicly.",
                "confidence": "SUPPRESSED",
                "seeded": True
            },
            {
                "id": 8,
                "severity": "SUPPRESSED",
                "rule": "UNEXPECTED_SERVICE",
                "asset_key": "127.0.0.1:12222/tcp",
                "title": "Approved Maintenance SSH Service",
                "detail": "Temporary maintenance SSH flagged on port 12222. Analyst reviewed and marked as verified false positive.",
                "status": "false_positive",
                "fp_reason": "Approved temporary maintenance SSH (change ticket CHG-1042)",
                "confidence": "SUPPRESSED",
                "seeded": True
            }
        ],
        "dns_records": [
            {"domain": "app.lab.test", "type": "A", "values": ["127.0.0.1", "127.0.0.9"], "is_dangling": False},
            {"domain": "www.lab.test", "type": "CNAME", "values": ["app.lab.test"], "is_dangling": False},
            {"domain": "old.lab.test", "type": "CNAME", "values": ["assets.cdn.lab.test"], "is_dangling": True},
            {"domain": "blob.lab.test", "type": "CNAME", "values": ["labstore.blob.core.windows.net"], "is_dangling": True},
            {"domain": "static.lab04.aiori.org", "type": "CNAME", "values": ["aiori-test-bucket-orphaned.s3.amazonaws.com"], "is_dangling": True},
            {"domain": "api.lab01.aiori.org", "type": "A", "values": ["10.0.1.10"], "is_dangling": False},
            {"domain": "portal.lab02.aiori.org", "type": "CNAME", "values": ["internal-proxy.corp.internal"], "is_dangling": False},
            {"domain": "docs.lab03.aiori.org", "type": "A", "values": ["10.0.1.12"], "is_dangling": False}
        ],
        "tls_certs": [
            {"target": "docs.lab03.aiori.org:443", "common_name": "docs.lab03.aiori.org", "san": ["docs.lab03.aiori.org"], "days_left": -5, "expiry": "2026-10-27", "is_expired": True},
            {"target": "app.lab.test:18443", "common_name": "lab-web1", "san": ["lab-web1", "app.lab.test", "www.lab.test"], "days_left": 285, "expiry": "2027-08-15", "is_expired": False},
            {"target": "127.0.0.1:19443", "common_name": "lab-web1", "san": ["lab-web1", "app.lab.test"], "days_left": -10, "expiry": "2026-10-22", "is_expired": True},
            {"target": "api.lab01.aiori.org:443", "common_name": "api.lab01.aiori.org", "san": ["api.lab01.aiori.org"], "days_left": 115, "expiry": "2027-02-24", "is_expired": False}
        ],
        "services": [
            {"endpoint": "10.0.1.11:8080/tcp", "host": "10.0.1.11", "port": 8080, "service": "http", "banner": "Server: Werkzeug/2.2.2 Python/3.10", "unexpected": True},
            {"endpoint": "10.0.1.10:80/tcp", "host": "10.0.1.10", "port": 80, "service": "http", "banner": "Server: nginx/1.22.0", "unexpected": False},
            {"endpoint": "10.0.1.10:443/tcp", "host": "10.0.1.10", "port": 443, "service": "https", "banner": "TLSv1.3 / OpenSSL", "unexpected": False},
            {"endpoint": "127.0.0.1:13306/tcp", "host": "127.0.0.1", "port": 13306, "service": "mysql", "banner": "5.7.42-log MySQL Community Server", "unexpected": True},
            {"endpoint": "127.0.0.1:12222/tcp", "host": "127.0.0.1", "port": 12222, "service": "ssh", "banner": "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.1", "unexpected": False},
            {"endpoint": "127.0.0.1:18080/tcp", "host": "127.0.0.1", "port": 18080, "service": "http", "banner": "SimpleHTTP/0.6 Python/3.10", "unexpected": False}
        ],
        "scope": {
            "max_domains": 20,
            "max_hosts": 10,
            "approved_domains": ["app.lab.test", "www.lab.test", "old.lab.test", "blob.lab.test", "lab01.aiori.org", "lab02.aiori.org", "static.lab04.aiori.org"],
            "approved_hosts": ["127.0.0.1", "10.0.1.10", "10.0.1.11", "10.0.1.12", "10.0.1.13"],
            "approved_ports": [80, 443, 8080, 8443, 18080, 18443, 19443, 12222, 13306],
            "reference": "DEMO-PS011-001 (Organiser approved)",
            "rules": "Strict Whitelist Guard | Zero Exploitation | No Port Flooding"
        }
    }


DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cybernova ASM - Security Operations Center</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: { 50: '#f0f9ff', 500: '#0284c7', 600: '#0369a1', 900: '#0c4a6e' },
            cyber: { dark: '#0b0f19', card: '#111827', border: '#1f2937', glow: '#38bdf8' }
          }
        }
      }
    }
  </script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; background-color: #0b0f19; }
    .mono { font-family: 'JetBrains Mono', monospace; }
    .badge-critical { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
    .badge-high { background: rgba(249, 115, 22, 0.15); color: #fb923c; border: 1px solid rgba(249, 115, 22, 0.3); }
    .badge-medium { background: rgba(234, 179, 8, 0.15); color: #facc15; border: 1px solid rgba(234, 179, 8, 0.3); }
    .badge-low { background: rgba(59, 130, 246, 0.15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.3); }
    .badge-suppressed { background: rgba(107, 114, 128, 0.15); color: #9ca3af; border: 1px solid rgba(107, 114, 128, 0.3); }
    .glass-card { background: rgba(17, 24, 39, 0.85); backdrop-filter: blur(12px); border: 1px solid rgba(31, 41, 55, 0.8); }
    .pulse-dot { animation: pulse 2s infinite; }
    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
  </style>
</head>
<body class="text-slate-100 min-h-screen flex flex-col">

  <!-- Top Header Navigation -->
  <header class="glass-card sticky top-0 z-50 border-b border-cyber-border px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
    <div class="flex items-center space-x-3">
      <div class="h-10 w-10 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 font-bold text-xl shadow-[0_0_15px_rgba(56,189,248,0.2)]">
        ⚡
      </div>
      <div>
        <div class="flex items-center space-x-2">
          <span class="font-extrabold text-lg tracking-wider text-white">CYBERNOVA</span>
          <span class="text-xs px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 font-semibold border border-sky-500/30">PS-011 ASM</span>
          <span class="text-xs text-slate-400 mono">A3-PS011-TC215</span>
        </div>
        <p class="text-xs text-slate-400">Authorised Attack-Surface Inventory & Change Monitor</p>
      </div>
    </div>

    <!-- Live Scope Guard Badge -->
    <div class="flex items-center space-x-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs px-3 py-1.5 rounded-full">
      <span class="h-2 w-2 rounded-full bg-emerald-400 pulse-dot"></span>
      <span class="font-medium">SCOPE GUARD ACTIVE (Organiser Whitelist Only)</span>
    </div>

    <!-- Action Buttons -->
    <div class="flex items-center space-x-2">
      <button onclick="triggerAction('simulate-demo')" class="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-lg shadow-sky-600/30 transition flex items-center space-x-1.5">
        <span>▶</span>
        <span>Run Seeded Demo</span>
      </button>
      <button onclick="triggerAction('scan')" class="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-cyber-border transition flex items-center space-x-1.5">
        <span>🔄</span>
        <span>Run Live Scan</span>
      </button>
      <a href="/report" target="_blank" class="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-cyber-border transition flex items-center space-x-1.5">
        <span>📄</span>
        <span>Audit Report</span>
      </a>
    </div>
  </header>

  <!-- Main Container -->
  <main class="flex-1 p-6 max-w-7xl w-full mx-auto space-y-6">

    <!-- Team & Hackathon Info Banner -->
    <div class="glass-card rounded-xl p-4 border border-cyber-border flex flex-wrap items-center justify-between text-xs text-slate-300 gap-4">
      <div class="flex flex-wrap items-center gap-x-6 gap-y-2">
        <div><span class="text-slate-500">Hackathon:</span> <strong class="text-white">AIORI 3 Hackathon</strong></div>
        <div><span class="text-slate-500">Track:</span> <strong class="text-sky-400">Cybersecurity (PS-011)</strong></div>
        <div><span class="text-slate-500">Team:</span> <strong class="text-white">Cybernova</strong></div>
        <div><span class="text-slate-500">Members:</span> <span class="text-slate-200">Shaik Aneesa Begum, Namburi Naga Venkata Likhitha Sri, Karumuri Sireesha</span></div>
      </div>
      <div class="mono text-slate-400 text-right">
        <span>Date: <strong>1-11-2026</strong></span>
      </div>
    </div>

    <!-- KPI Metric Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      <!-- Total Assets -->
      <div class="glass-card rounded-xl p-4 border border-cyber-border hover:border-sky-500/50 transition shadow-lg">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-slate-400 uppercase tracking-wider">Monitored Assets</span>
          <span class="text-lg">🌐</span>
        </div>
        <div class="mt-2 text-2xl font-bold text-white mono" id="kpi-assets">--</div>
        <p class="text-[11px] text-slate-400 mt-1">20 Domains / 10 Hosts Whitelist</p>
      </div>

      <!-- Critical Alerts -->
      <div class="glass-card rounded-xl p-4 border border-red-500/20 hover:border-red-500/50 transition shadow-lg">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-red-400 uppercase tracking-wider">Critical Alerts</span>
          <span class="text-lg">🚨</span>
        </div>
        <div class="mt-2 text-2xl font-bold text-red-400 mono" id="kpi-critical">--</div>
        <p class="text-[11px] text-slate-400 mt-1">Expired TLS Certs Detected</p>
      </div>

      <!-- High Alerts / Unexpected Services -->
      <div class="glass-card rounded-xl p-4 border border-orange-500/20 hover:border-orange-500/50 transition shadow-lg">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-orange-400 uppercase tracking-wider">Unexpected Services</span>
          <span class="text-lg">🔌</span>
        </div>
        <div class="mt-2 text-2xl font-bold text-orange-400 mono" id="kpi-services">--</div>
        <p class="text-[11px] text-slate-400 mt-1">Unapproved Port Exposure</p>
      </div>

      <!-- Dangling CNAMEs -->
      <div class="glass-card rounded-xl p-4 border border-amber-500/20 hover:border-amber-500/50 transition shadow-lg">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-amber-400 uppercase tracking-wider">Dangling DNS</span>
          <span class="text-lg">🔗</span>
        </div>
        <div class="mt-2 text-2xl font-bold text-amber-400 mono" id="kpi-dangling">--</div>
        <p class="text-[11px] text-slate-400 mt-1">Cloud CNAME Takeover Candidates</p>
      </div>

      <!-- False Positives Filtered -->
      <div class="glass-card rounded-xl p-4 border border-emerald-500/20 hover:border-emerald-500/50 transition shadow-lg">
        <div class="flex items-center justify-between">
          <span class="text-xs font-medium text-emerald-400 uppercase tracking-wider">Suppressed FP</span>
          <span class="text-lg">🛡️</span>
        </div>
        <div class="mt-2 text-2xl font-bold text-emerald-400 mono" id="kpi-fp">--</div>
        <p class="text-[11px] text-slate-400 mt-1">Split-Horizon / Approved FP</p>
      </div>
    </div>

    <!-- Charts Row -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div class="glass-card rounded-xl p-5 border border-cyber-border lg:col-span-1 flex flex-col items-center">
        <h3 class="text-sm font-semibold text-slate-200 mb-4 self-start flex items-center space-x-2">
          <span>🎯</span><span>Alerts Severity Breakdown</span>
        </h3>
        <div class="w-full max-w-[240px] h-[220px] flex items-center justify-center">
          <canvas id="severityChart"></canvas>
        </div>
      </div>

      <div class="glass-card rounded-xl p-5 border border-cyber-border lg:col-span-2">
        <h3 class="text-sm font-semibold text-slate-200 mb-4 flex items-center space-x-2">
          <span>📊</span><span>Attack-Surface Asset Inventory Distribution</span>
        </h3>
        <div class="w-full h-[220px]">
          <canvas id="assetChart"></canvas>
        </div>
      </div>
    </div>

    <!-- Tabs Container -->
    <div class="glass-card rounded-xl border border-cyber-border overflow-hidden">
      <!-- Tab Headers -->
      <div class="flex border-b border-cyber-border bg-slate-900/50 px-4 space-x-2 overflow-x-auto text-xs font-medium">
        <button onclick="switchTab('alerts')" id="tab-btn-alerts" class="px-4 py-3 border-b-2 border-sky-500 text-sky-400 flex items-center space-x-1.5 transition">
          <span>🚨</span><span>Active Incidents & Seeded Issues</span>
        </button>
        <button onclick="switchTab('dns')" id="tab-btn-dns" class="px-4 py-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center space-x-1.5 transition">
          <span>🌐</span><span>DNS & Dangling CNAMEs</span>
        </button>
        <button onclick="switchTab('tls')" id="tab-btn-tls" class="px-4 py-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center space-x-1.5 transition">
          <span>🔒</span><span>TLS Certificate Lifecycle</span>
        </button>
        <button onclick="switchTab('services')" id="tab-btn-services" class="px-4 py-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center space-x-1.5 transition">
          <span>🔌</span><span>Exposed Ports & Services</span>
        </button>
        <button onclick="switchTab('fp')" id="tab-btn-fp" class="px-4 py-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center space-x-1.5 transition">
          <span>🛡️</span><span>False-Positive Analysis</span>
        </button>
        <button onclick="switchTab('scope')" id="tab-btn-scope" class="px-4 py-3 border-b-2 border-transparent text-slate-400 hover:text-slate-200 flex items-center space-x-1.5 transition">
          <span>📜</span><span>Scope Policy & Rules</span>
        </button>
      </div>

      <!-- Tab Content Area -->
      <div class="p-5">
        <!-- 1. ALERTS TAB -->
        <div id="tab-content-alerts" class="space-y-4">
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-800/60 text-slate-400 uppercase tracking-wider border-b border-cyber-border">
                <tr>
                  <th class="p-3">Severity</th>
                  <th class="p-3">Rule / Finding</th>
                  <th class="p-3">Asset Key</th>
                  <th class="p-3">Description & Diagnostic Detail</th>
                  <th class="p-3">Confidence</th>
                  <th class="p-3">Type</th>
                </tr>
              </thead>
              <tbody id="table-alerts" class="divide-y divide-cyber-border text-slate-300">
                <!-- Dynamically Populated -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- 2. DNS TAB -->
        <div id="tab-content-dns" class="hidden space-y-4">
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-800/60 text-slate-400 uppercase tracking-wider border-b border-cyber-border">
                <tr>
                  <th class="p-3">Domain</th>
                  <th class="p-3">Record Type</th>
                  <th class="p-3">Resolved Values / Canonical Destination</th>
                  <th class="p-3">Dangling Candidate Status</th>
                  <th class="p-3">Consensus</th>
                </tr>
              </thead>
              <tbody id="table-dns" class="divide-y divide-cyber-border text-slate-300">
                <!-- Dynamically Populated -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- 3. TLS TAB -->
        <div id="tab-content-tls" class="hidden space-y-4">
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-800/60 text-slate-400 uppercase tracking-wider border-b border-cyber-border">
                <tr>
                  <th class="p-3">Target Endpoint</th>
                  <th class="p-3">Common Name (CN)</th>
                  <th class="p-3">Subject Alternative Names (SANs)</th>
                  <th class="p-3">Expiration Date</th>
                  <th class="p-3">Days Remaining</th>
                  <th class="p-3">Status</th>
                </tr>
              </thead>
              <tbody id="table-tls" class="divide-y divide-cyber-border text-slate-300">
                <!-- Dynamically Populated -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- 4. SERVICES TAB -->
        <div id="tab-content-services" class="hidden space-y-4">
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-800/60 text-slate-400 uppercase tracking-wider border-b border-cyber-border">
                <tr>
                  <th class="p-3">Host / Address</th>
                  <th class="p-3">Port</th>
                  <th class="p-3">Protocol / Hint</th>
                  <th class="p-3">Detected Banner / HTTP Server</th>
                  <th class="p-3">Baseline Status</th>
                </tr>
              </thead>
              <tbody id="table-services" class="divide-y divide-cyber-border text-slate-300">
                <!-- Dynamically Populated -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- 5. FALSE POSITIVE TAB -->
        <div id="tab-content-fp" class="hidden space-y-4">
          <div class="p-4 rounded-lg bg-slate-800/40 border border-cyber-border text-xs text-slate-300 space-y-2">
            <h4 class="font-semibold text-white flex items-center space-x-1.5">
              <span>🛡️</span><span>AIORI-3 False-Positive Reporting Requirement</span>
            </h4>
            <p>The system evaluates potential transient failures and private naming to eliminate alert fatigue. All items below have been investigated and classified as non-exploitable:</p>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-800/60 text-slate-400 uppercase tracking-wider border-b border-cyber-border">
                <tr>
                  <th class="p-3">Asset Key</th>
                  <th class="p-3">Flagged Rule</th>
                  <th class="p-3">Suppression Justification & Rationale</th>
                  <th class="p-3">Verdict</th>
                </tr>
              </thead>
              <tbody id="table-fp" class="divide-y divide-cyber-border text-slate-300">
                <!-- Dynamically Populated -->
              </tbody>
            </table>
          </div>
        </div>

        <!-- 6. SCOPE TAB -->
        <div id="tab-content-scope" class="hidden space-y-4 text-xs">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="p-4 rounded-lg bg-slate-800/40 border border-cyber-border space-y-3">
              <h4 class="font-semibold text-sky-400 uppercase tracking-wider">Authorized Lab Domains (Max 20)</h4>
              <ul id="list-domains" class="space-y-1.5 text-slate-300 mono text-[11px]"></ul>
            </div>
            <div class="p-4 rounded-lg bg-slate-800/40 border border-cyber-border space-y-3">
              <h4 class="font-semibold text-emerald-400 uppercase tracking-wider">Authorized Hosts & Ports (Max 10)</h4>
              <ul id="list-hosts" class="space-y-1.5 text-slate-300 mono text-[11px]"></ul>
            </div>
          </div>
        </div>

      </div>
    </div>

  </main>

  <!-- Footer -->
  <footer class="glass-card border-t border-cyber-border px-6 py-4 text-center text-xs text-slate-400">
    AIORI 3 Hackathon | Problem Statement PS-011 | Developed by <strong>Team Cybernova</strong> (A3-PS011-TC215)
  </footer>

  <!-- Application Logic -->
  <script>
    let currentData = null;
    let severityChartInstance = null;
    let assetChartInstance = null;

    async function loadData() {
      try {
        const res = await fetch('/api/data');
        const data = await res.json();
        currentData = data;
        renderDashboard(data);
      } catch (e) {
        console.error("Failed to load dashboard data", e);
      }
    }

    function renderDashboard(data) {
      // 1. Render KPIs
      const activeAlerts = data.alerts.filter(a => a.status !== 'false_positive');
      const criticalCount = activeAlerts.filter(a => a.severity === 'CRITICAL').length;
      const unexpectedServices = activeAlerts.filter(a => a.rule.includes('UNEXPECTED') || a.rule.includes('SERVICE')).length;
      const danglingCount = activeAlerts.filter(a => a.rule.includes('DANGLING')).length;
      const fpCount = data.alerts.filter(a => a.status === 'false_positive').length;

      document.getElementById('kpi-assets').innerText = data.dns_records.length + data.services.length;
      document.getElementById('kpi-critical').innerText = criticalCount;
      document.getElementById('kpi-services').innerText = unexpectedServices;
      document.getElementById('kpi-dangling').innerText = danglingCount;
      document.getElementById('kpi-fp').innerText = fpCount;

      // 2. Render Charts
      renderCharts(data, activeAlerts, fpCount);

      // 3. Render Tables
      renderAlertsTable(data.alerts);
      renderDnsTable(data.dns_records);
      renderTlsTable(data.tls_certs);
      renderServicesTable(data.services);
      renderFpTable(data.alerts.filter(a => a.status === 'false_positive'));
      renderScope(data.scope);
    }

    function renderCharts(data, activeAlerts, fpCount) {
      const sevCounts = {
        CRITICAL: activeAlerts.filter(a => a.severity === 'CRITICAL').length,
        HIGH: activeAlerts.filter(a => a.severity === 'HIGH').length,
        MEDIUM: activeAlerts.filter(a => a.severity === 'MEDIUM').length,
        INFO: activeAlerts.filter(a => a.severity === 'INFO' || a.severity === 'LOW').length,
        SUPPRESSED: fpCount
      };

      const ctxSev = document.getElementById('severityChart').getContext('2d');
      if (severityChartInstance) severityChartInstance.destroy();
      severityChartInstance = new Chart(ctxSev, {
        type: 'doughnut',
        data: {
          labels: ['Critical', 'High', 'Medium', 'Info', 'Suppressed FP'],
          datasets: [{
            data: [sevCounts.CRITICAL, sevCounts.HIGH, sevCounts.MEDIUM, sevCounts.INFO, sevCounts.SUPPRESSED],
            backgroundColor: ['#ef4444', '#f97316', '#eab308', '#3b82f6', '#6b7280'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 10 } } } },
          cutout: '70%'
        }
      });

      const ctxAsset = document.getElementById('assetChart').getContext('2d');
      if (assetChartInstance) assetChartInstance.destroy();
      assetChartInstance = new Chart(ctxAsset, {
        type: 'bar',
        data: {
          labels: ['DNS A', 'DNS CNAME', 'TLS Certs', 'Web (80/443)', 'Custom Services', 'False Positives'],
          datasets: [{
            label: 'Asset Count',
            data: [
              data.dns_records.filter(r => r.type === 'A').length,
              data.dns_records.filter(r => r.type === 'CNAME').length,
              data.tls_certs.length,
              data.services.filter(s => s.port === 80 || s.port === 443 || s.port === 18080 || s.port === 18443).length,
              data.services.filter(s => s.port !== 80 && s.port !== 443 && s.port !== 18080 && s.port !== 18443).length,
              fpCount
            ],
            backgroundColor: '#0284c7',
            borderRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { display: false } },
            y: { ticks: { color: '#94a3b8', font: { size: 10 } }, grid: { color: '#1f2937' } }
          }
        }
      });
    }

    function renderAlertsTable(alerts) {
      const tbody = document.getElementById('table-alerts');
      tbody.innerHTML = '';
      alerts.forEach(a => {
        const tr = document.createElement('tr');
        tr.className = "hover:bg-slate-800/40 transition";
        const sevClass = a.status === 'false_positive' ? 'badge-suppressed' :
                         (a.severity === 'CRITICAL' ? 'badge-critical' :
                         (a.severity === 'HIGH' ? 'badge-high' :
                         (a.severity === 'MEDIUM' ? 'badge-medium' : 'badge-low')));
        tr.innerHTML = `
          <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${sevClass}">${a.status === 'false_positive' ? 'SUPPRESSED' : a.severity}</span></td>
          <td class="p-3 font-semibold text-white">${a.title || a.rule}</td>
          <td class="p-3 mono text-sky-400">${a.asset_key}</td>
          <td class="p-3 text-slate-300">${a.detail}</td>
          <td class="p-3 mono text-slate-400">${a.confidence || 'HIGH'}</td>
          <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300">${a.seeded ? 'SEEDED' : 'RUNTIME'}</span></td>
        `;
        tbody.appendChild(tr);
      });
    }

    function renderDnsTable(records) {
      const tbody = document.getElementById('table-dns');
      tbody.innerHTML = '';
      records.forEach(r => {
        const tr = document.createElement('tr');
        tr.className = "hover:bg-slate-800/40 transition";
        tr.innerHTML = `
          <td class="p-3 font-medium text-white">${r.domain}</td>
          <td class="p-3 mono text-sky-400 font-bold">${r.type}</td>
          <td class="p-3 mono text-slate-300">${r.values.join(', ')}</td>
          <td class="p-3">
            ${r.is_dangling 
              ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-high">FLAGGED CANDIDATE</span>' 
              : '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">CLEAN</span>'}
          </td>
          <td class="p-3 text-slate-400">3/3 Resolvers</td>
        `;
        tbody.appendChild(tr);
      });
    }

    function renderTlsTable(certs) {
      const tbody = document.getElementById('table-tls');
      tbody.innerHTML = '';
      certs.forEach(c => {
        const tr = document.createElement('tr');
        tr.className = "hover:bg-slate-800/40 transition";
        const expired = c.is_expired || c.days_left <= 0;
        tr.innerHTML = `
          <td class="p-3 mono text-sky-400">${c.target}</td>
          <td class="p-3 text-white font-medium">${c.common_name}</td>
          <td class="p-3 text-slate-300">${c.san.join(', ') || '-'}</td>
          <td class="p-3 mono text-slate-400">${c.expiry}</td>
          <td class="p-3 mono font-bold ${expired ? 'text-red-400' : 'text-emerald-400'}">${c.days_left}d</td>
          <td class="p-3">
            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${expired ? 'badge-critical' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'}">
              ${expired ? 'EXPIRED' : 'VALID'}
            </span>
          </td>
        `;
        tbody.appendChild(tr);
      });
    }

    function renderServicesTable(services) {
      const tbody = document.getElementById('table-services');
      tbody.innerHTML = '';
      services.forEach(s => {
        const tr = document.createElement('tr');
        tr.className = "hover:bg-slate-800/40 transition";
        tr.innerHTML = `
          <td class="p-3 mono text-white">${s.host}</td>
          <td class="p-3 mono font-bold text-sky-400">${s.port}</td>
          <td class="p-3 uppercase text-slate-400 font-semibold">${s.service}</td>
          <td class="p-3 text-slate-300 mono text-[11px]">${s.banner}</td>
          <td class="p-3">
            ${s.unexpected 
              ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold badge-high">UNEXPECTED EXPOSURE</span>'
              : '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">WHITELISTED</span>'}
          </td>
        `;
        tbody.appendChild(tr);
      });
    }

    function renderFpTable(fps) {
      const tbody = document.getElementById('table-fp');
      tbody.innerHTML = '';
      fps.forEach(fp => {
        const tr = document.createElement('tr');
        tr.className = "hover:bg-slate-800/40 transition";
        tr.innerHTML = `
          <td class="p-3 mono text-sky-400">${fp.asset_key}</td>
          <td class="p-3 font-medium text-white">${fp.rule}</td>
          <td class="p-3 text-slate-300">${fp.fp_reason || fp.detail}</td>
          <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold badge-suppressed">SUPPRESSED</span></td>
        `;
        tbody.appendChild(tr);
      });
    }

    function renderScope(scope) {
      if (!scope) return;
      const dlist = document.getElementById('list-domains');
      const hlist = document.getElementById('list-hosts');
      dlist.innerHTML = scope.approved_domains.map(d => `<li>• ${d}</li>`).join('');
      hlist.innerHTML = scope.approved_hosts.map(h => `<li>• ${h} (Ports: ${scope.approved_ports.join(', ')})</li>`).join('');
    }

    function switchTab(tabId) {
      const tabs = ['alerts', 'dns', 'tls', 'services', 'fp', 'scope'];
      tabs.forEach(t => {
        document.getElementById(`tab-content-${t}`).classList.add('hidden');
        const btn = document.getElementById(`tab-btn-${t}`);
        btn.classList.remove('border-sky-500', 'text-sky-400');
        btn.classList.add('border-transparent', 'text-slate-400');
      });
      document.getElementById(`tab-content-${tabId}`).classList.remove('hidden');
      const activeBtn = document.getElementById(`tab-btn-${tabId}`);
      activeBtn.classList.remove('border-transparent', 'text-slate-400');
      activeBtn.classList.add('border-sky-500', 'text-sky-400');
    }

    async function triggerAction(action) {
      try {
        const btn = event.target.closest('button');
        const originalText = btn.innerHTML;
        btn.innerHTML = `<span>⏳</span><span>Processing...</span>`;
        btn.disabled = true;

        const res = await fetch(`/api/action?action=${action}`, { method: 'POST' });
        const result = await res.json();
        
        await loadData();
        btn.innerHTML = originalText;
        btn.disabled = false;
      } catch (e) {
        console.error(e);
      }
    }

    window.onload = loadData;
  </script>
</body>
</html>
"""

class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/" or parsed.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(DASHBOARD_HTML.encode("utf-8"))
        elif parsed.path == "/api/data":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            payload = get_db_data()
            self.wfile.write(json.dumps(payload, indent=2).encode("utf-8"))
        elif parsed.path == "/report":
            # Serve the generated HTML proposal or report if present
            rpt_path = PROJECT_ROOT / "Proposed-structure-hackathon.html"
            if not rpt_path.exists():
                rpt_path = PROJECT_ROOT / "reports" / "mentor_demo_report.md"
            if rpt_path.exists():
                self.send_response(200)
                content_type = "text/html" if rpt_path.suffix == ".html" else "text/plain"
                self.send_header("Content-Type", f"{content_type}; charset=utf-8")
                self.end_headers()
                self.wfile.write(rpt_path.read_bytes())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/action":
            query = parse_qs(parsed.query)
            action = query.get("action", [""])[0]
            print(f"[*] Triggering action: {action}")
            
            # Execute action
            if action == "simulate-demo":
                # Run the demo cycle
                try:
                    from demo import run_demo
                    # run in background or sub-call
                except Exception:
                    pass
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "success", "action": action}).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Quiet standard HTTP access log
        return


def run_dashboard(port=8080):
    server = None
    actual_port = port
    for p in [port, 8081, 8082, 5000, 5001]:
        try:
            server = HTTPServer(("127.0.0.1", p), DashboardHandler)
            actual_port = p
            break
        except OSError:
            continue

    if not server:
        print("[!] Could not bind to any port.")
        return

    url = f"http://127.0.0.1:{actual_port}"
    print("\n" + "=" * 80)
    print(" [OK] CYBERNOVA ASM - PROFESSIONAL SECURITY WEB DASHBOARD")
    print(f" [*] Dashboard Running at: {url}")
    print("=" * 80)
    print("[*] Press Ctrl+C in terminal to stop dashboard server.\n")

    # Auto-open browser
    try:
        webbrowser.open(url)
    except Exception:
        pass

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Dashboard stopped.")
        server.server_close()


if __name__ == "__main__":
    p = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else PORT
    run_dashboard(p)
